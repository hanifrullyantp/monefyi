export { default } from './HrEmployees';
