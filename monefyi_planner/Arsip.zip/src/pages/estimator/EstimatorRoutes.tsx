import { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { useAppStore } from '../../store/appStore';
import EstimatorAccessGuard from '../../components/entitlement/EstimatorAccessGuard';
import EstimatorListPage from './EstimatorListPage';
import EstimatorForm from './EstimatorForm';
import PricelistPage from './PricelistPage';
import EstimatorSettings from './EstimatorSettings';

export default function EstimatorRoutes() {
  const location = useLocation();
  const setActiveTab = useAppStore(s => s.setActiveTab);

  useEffect(() => {
    setActiveTab('estimator');
  }, [location.pathname, setActiveTab]);

  return (
    <EstimatorAccessGuard>
      <Routes>
        <Route index element={<EstimatorListPage />} />
        <Route path="new" element={<EstimatorForm />} />
        <Route path="pricelist" element={<PricelistPage />} />
        <Route path="settings" element={<EstimatorSettings />} />
        <Route path=":id" element={<EstimatorForm />} />
      </Routes>
    </EstimatorAccessGuard>
  );
}
