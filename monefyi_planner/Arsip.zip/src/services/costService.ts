import { type DbCostRealization } from '../lib/adapters';
import { supabase } from '../lib/supabase';
import { assertNoDbError } from '../lib/supabaseErrors';
import { loadRapItems } from './rapService';

export type CostRealization = DbCostRealization;

export interface RapActualAgg {
  qty: number;
  amount: number;
  lastDate?: string;
  lastRecordedBy?: string;
  lastCostId?: string;
}

/** Membaca total_spent yang dihitung trigger. Klien tidak menulis kolom turunan. */
export async function recalculateProjectSpent(projectId: string) {
  const { data, error } = await supabase
    .from('planner_projects')
    .select('total_spent')
    .eq('id', projectId)
    .single();
  if (error) throw new Error(error.message);
  return Number(data?.total_spent) || 0;
}

export async function deleteAllCosts(projectId: string) {
  const { data: existing } = await supabase
    .from('planner_cost_realizations')
    .select('journal_entry_id, description')
    .eq('project_id', projectId)
    .not('journal_entry_id', 'is', null);

  const { error } = await supabase.from('planner_cost_realizations').delete().eq('project_id', projectId);
  if (error) throw new Error(error.message);
  await recalculateProjectSpent(projectId);

  if (existing && existing.length > 0) {
    try {
      const { reverseProjectJournal } = await import('./financeV2/projectJournalBridge');
      for (const row of existing) {
        await reverseProjectJournal(
          row.journal_entry_id as string | null,
          `Batal biaya proyek: ${(row.description as string) || ''}`.trim(),
        );
      }
    } catch (e) {
      console.error('Journal reversal on deleteAllCosts failed:', e);
    }
  }
}

export async function loadCostRealizations(projectId: string): Promise<CostRealization[]> {
  const { data, error } = await supabase
    .from('planner_cost_realizations')
    .select('*')
    .eq('project_id', projectId)
    .order('date', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as CostRealization[];
}

export async function loadAllCosts(orgId: string): Promise<CostRealization[]> {
  const { data: projects, error: projErr } = await supabase
    .from('planner_projects')
    .select('id')
    .eq('org_id', orgId);
  if (projErr) throw new Error(projErr.message);

  const ids = (projects || []).map(p => p.id);
  if (!ids.length) return [];

  const { data, error } = await supabase
    .from('planner_cost_realizations')
    .select('*')
    .in('project_id', ids)
    .order('date', { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []) as CostRealization[];
}

export async function createCostRealization(
  item: Omit<CostRealization, 'id' | 'created_at' | 'updated_at'>,
) {
  const { data, error } = await supabase
    .from('planner_cost_realizations')
    .insert(item)
    .select()
    .single();

  if (error) throw new Error(error.message);

  await recalculateProjectSpent(item.project_id);

  const amount = Number(data.total_amount) || 0;
  if (amount > 0) {
    try {
      const { postProjectExpenseJournal } = await import('./financeV2/projectJournalBridge');
      const journalId = await postProjectExpenseJournal({
        projectId: item.project_id,
        amount,
        description: `Biaya proyek: ${item.description || ''}`,
        referenceId: data.id,
        entryDate: item.date,
        createdBy: item.recorded_by,
      });
      if (journalId) {
        await supabase
          .from('planner_cost_realizations')
          .update({ journal_entry_id: journalId, synced_at: new Date().toISOString() })
          .eq('id', data.id);
      }
    } catch (e) {
      console.error('Journal expense post failed:', e);
    }
  }

  return data as CostRealization;
}

export async function deleteCostRealization(id: string, projectId: string) {
  const { data: existing } = await supabase
    .from('planner_cost_realizations')
    .select('journal_entry_id, description')
    .eq('id', id)
    .maybeSingle();

  const { error } = await supabase.from('planner_cost_realizations').delete().eq('id', id);
  if (error) throw new Error(error.message);

  await recalculateProjectSpent(projectId);

  if (existing?.journal_entry_id) {
    try {
      const { reverseProjectJournal } = await import('./financeV2/projectJournalBridge');
      await reverseProjectJournal(
        existing.journal_entry_id as string,
        `Batal biaya proyek: ${(existing.description as string) || ''}`.trim(),
      );
    } catch (e) {
      console.error('Journal reversal on deleteCostRealization failed:', e);
    }
  }
}

export async function deleteCostsByRapItemId(projectId: string, rapItemId: string) {
  const { data: existing } = await supabase
    .from('planner_cost_realizations')
    .select('journal_entry_id, description')
    .eq('project_id', projectId)
    .eq('rap_item_id', rapItemId)
    .not('journal_entry_id', 'is', null);

  const { error } = await supabase
    .from('planner_cost_realizations')
    .delete()
    .eq('project_id', projectId)
    .eq('rap_item_id', rapItemId);
  if (error) throw new Error(error.message);
  await recalculateProjectSpent(projectId);

  if (existing && existing.length > 0) {
    try {
      const { reverseProjectJournal } = await import('./financeV2/projectJournalBridge');
      for (const row of existing) {
        await reverseProjectJournal(
          row.journal_entry_id as string | null,
          `Batal realisasi RAP: ${(row.description as string) || ''}`.trim(),
        );
      }
    } catch (e) {
      console.error('Journal reversal on deleteCostsByRapItemId failed:', e);
    }
  }
}

/** Toggle checklist realisasi: satu baris konsolidasi per item RAP. */
export async function setRapItemRealization(input: {
  projectId: string;
  rapItemId: string;
  rapItemName: string;
  plannedQty: number;
  plannedUnitPrice: number;
  realized: boolean;
  amount?: number | null;
  actualQty?: number | null;
  recordedBy: string;
  date?: string;
}) {
  const { projectId, rapItemId, realized } = input;

  await deleteCostsByRapItemId(projectId, rapItemId);

  if (!realized) return;

  const plannedQty = Math.max(0, Number(input.plannedQty) || 0);
  const plannedUnitPrice = Number(input.plannedUnitPrice) || 0;
  const plannedTotal = Math.round(plannedQty * plannedUnitPrice);

  let quantity = plannedQty;
  let unitPrice = plannedUnitPrice;
  let totalAmount = plannedTotal;

  if (input.actualQty != null && input.actualQty >= 0) {
    quantity = input.actualQty;
    unitPrice = plannedUnitPrice;
    totalAmount = Math.round(quantity * unitPrice);
  } else {
    const customAmount = input.amount != null && input.amount > 0 ? Math.round(input.amount) : null;
    totalAmount = customAmount ?? plannedTotal;
    if (customAmount != null && customAmount !== plannedTotal) {
      quantity = 1;
      unitPrice = customAmount;
    }
  }

  if (totalAmount <= 0) return;

  await createCostRealization({
    project_id: projectId,
    rap_item_id: rapItemId,
    date: input.date || new Date().toISOString().slice(0, 10),
    description: `Realisasi: ${input.rapItemName}`,
    quantity,
    unit_price: unitPrice,
    total_amount: totalAmount,
    recorded_by: input.recordedBy,
    status: 'recorded',
  });
}

export async function updateCostRealization(
  id: string,
  projectId: string,
  patch: Partial<Pick<CostRealization, 'date' | 'description' | 'quantity' | 'unit_price' | 'total_amount'>>,
) {
  const { error } = await supabase.from('planner_cost_realizations').update(patch).eq('id', id);
  if (error) throw new Error(error.message);
  await recalculateProjectSpent(projectId);
}

export async function aggregateCostByRapItem(projectId: string) {
  const costs = await loadCostRealizations(projectId);
  const byRap: Record<string, RapActualAgg> = {};

  for (const c of costs) {
    if (!c.rap_item_id) continue;
    if (!byRap[c.rap_item_id]) {
      byRap[c.rap_item_id] = { qty: 0, amount: 0 };
    }
    const agg = byRap[c.rap_item_id];
    agg.qty += Number(c.quantity) || 0;
    agg.amount += Number(c.total_amount) || 0;
    const d = c.date || '';
    if (!agg.lastDate || d > agg.lastDate) {
      agg.lastDate = d;
      agg.lastRecordedBy = c.recorded_by;
      agg.lastCostId = c.id;
    }
  }

  return byRap;
}

export async function aggregateCashflow(orgId: string, days = 30) {
  const costs = await loadAllCosts(orgId);
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);

  const byDay: Record<string, number> = {};
  for (let i = 0; i < days; i++) {
    const d = new Date();
    d.setDate(d.getDate() - (days - 1 - i));
    byDay[d.toISOString().slice(0, 10)] = 0;
  }

  for (const c of costs) {
    const d = c.date;
    if (new Date(d) >= cutoff) {
      byDay[d] = (byDay[d] || 0) + (Number(c.total_amount) || 0);
    }
  }

  return Object.entries(byDay).map(([date, amount]) => ({
    date: new Date(date).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }),
    amount: amount / 1_000_000,
  }));
}

export async function aggregateByProject(orgId: string) {
  const { data: projects, error } = await supabase
    .from('planner_projects')
    .select('id, name, total_budget, total_spent, total_received')
    .eq('org_id', orgId);
  if (error) throw new Error(error.message);

  return (projects || []).map(p => ({
    projectId: p.id,
    name: p.name,
    budget: Number(p.total_budget) || 0,
    spent: Number(p.total_spent) || 0,
    received: Number(p.total_received) || 0,
  }));
}

/** Gabungkan duplikat import & hitung ulang nominal dari RAP saat ini (Vol × Harga Satuan). */
export async function repairImportCosts(projectId: string, recordedBy: string) {
  const [costs, rapItems] = await Promise.all([
    loadCostRealizations(projectId),
    loadRapItems(projectId),
  ]);

  const rapById = new Map(rapItems.map(r => [r.id, r]));
  const importCosts = costs.filter(c => String(c.description || '').startsWith('Import:'));
  if (!importCosts.length) {
    return { removed: 0, fixed: 0, totalSpent: await recalculateProjectSpent(projectId) };
  }

  const groups = new Map<string, CostRealization[]>();
  for (const c of importCosts) {
    const key = c.rap_item_id || String(c.description || '').trim().toLowerCase();
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(c);
  }

  const idsToDelete = importCosts.map(c => c.id);
  const { error: delErr } = await supabase
    .from('planner_cost_realizations')
    .delete()
    .in('id', idsToDelete);
  if (delErr) throw new Error(delErr.message);

  const today = new Date().toISOString().slice(0, 10);
  const inserts: Omit<CostRealization, 'id' | 'created_at' | 'updated_at'>[] = [];

  for (const [, group] of groups) {
    const first = group[0];
    const rap = first.rap_item_id ? rapById.get(first.rap_item_id) : undefined;
    if (!rap) continue;

    const qty = Number(first.quantity) || Number(rap.quantity) || 0;
    const unitPrice = Number(rap.unit_price) || 0;
    if (qty <= 0 || unitPrice <= 0) continue;

    inserts.push({
      project_id: projectId,
      rap_item_id: rap.id,
      date: first.date || today,
      description: `Import: ${rap.name}`,
      quantity: qty,
      unit_price: unitPrice,
      total_amount: qty * unitPrice,
      recorded_by: recordedBy,
      status: 'recorded',
    });
  }

  if (inserts.length) {
    const { error: insErr } = await supabase.from('planner_cost_realizations').insert(inserts);
    if (insErr) throw new Error(insErr.message);
  }

  const totalSpent = await recalculateProjectSpent(projectId);
  return { removed: idsToDelete.length, fixed: inserts.length, totalSpent };
}
