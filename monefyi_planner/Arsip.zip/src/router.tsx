import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import LandingEntry from './components/LandingEntry';
import { LoginPage } from './components/AuthPages';
import ProtectedRoute from './components/ProtectedRoute';
import AuthOnlyRoute from './components/AuthOnlyRoute';
import AppShell from './components/AppShell';
import ErrorBoundary from './components/ErrorBoundary';
import AuthBootstrap from './components/AuthBootstrap';
import AuthRedirect from './components/AuthRedirect';
import { PrivacyPage, TermsPage, ContactPage } from './pages/LegalPages';
import { SignupHubPage } from './pages/auth/SignupHub';
import { OwnerSignupPage } from './pages/auth/OwnerSignup';
import { VerifyEmailPage } from './pages/auth/VerifyEmail';
import { JoinByTokenPage } from './pages/join/JoinByToken';
import { JoinByCodePage } from './pages/join/JoinByCode';
import { FindCompanyPage } from './pages/join/FindCompany';
import { OwnerOnboardingWizard } from './pages/onboarding/OwnerWizard';
import { MemberOnboardingWizard } from './pages/onboarding/MemberWizard';
import AdminRoute from './components/AdminRoute';
import SuperAdmin from './pages/SuperAdmin';
import PwaInstallBanner from './components/PwaInstallBanner';
import PaymentReturnHandler from './components/entitlement/PaymentReturnHandler';
import DemoEmbedPage from './pages/demo/DemoEmbedPage';

export default function AppRouter() {
  return (
    <BrowserRouter useTransitions={false}>
      <AuthBootstrap>
      <PaymentReturnHandler />
      <PwaInstallBanner />
      <Routes>
        <Route path="/" element={<><AuthRedirect /><LandingEntry /></>} />
        <Route path="/login" element={<><AuthRedirect /><LoginPage /></>} />
        <Route path="/signup" element={<><AuthRedirect /><SignupHubPage /></>} />
        <Route path="/signup/owner" element={<><AuthRedirect /><OwnerSignupPage /></>} />
        <Route path="/verify-email" element={<VerifyEmailPage />} />
        <Route path="/join" element={<JoinByTokenPage />} />
        <Route path="/join-by-code" element={<JoinByCodePage />} />
        <Route path="/find-company" element={<FindCompanyPage />} />
        <Route path="/onboarding/owner" element={<AuthOnlyRoute><OwnerOnboardingWizard /></AuthOnlyRoute>} />
        <Route path="/onboarding/member" element={<AuthOnlyRoute><MemberOnboardingWizard /></AuthOnlyRoute>} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/demo-embed" element={<ErrorBoundary componentName="DemoEmbed"><DemoEmbedPage /></ErrorBoundary>} />
        <Route path="/app/*" element={<ProtectedRoute><ErrorBoundary componentName="App"><AppShell /></ErrorBoundary></ProtectedRoute>} />
        <Route path="/admin" element={<AdminRoute><SuperAdmin /></AdminRoute>} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
      </AuthBootstrap>
    </BrowserRouter>
  );
}
