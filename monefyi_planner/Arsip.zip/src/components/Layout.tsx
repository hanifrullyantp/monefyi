import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home, FolderOpen, Wallet, Settings, Bell, Menu, X, ArrowLeft,
  Sparkles, Wifi, WifiOff, Clock, Users, Receipt,
  BarChart3, Shield, ChevronRight, Database, PanelRightClose, PanelRight, Lock, User,
} from 'lucide-react';
import { useAppStore } from '../store/appStore';
import { useUiStore } from '../store/uiStore';
import { isPlatformAdmin } from '../services/adminService';
import { showWorkerShell, canAccessManagerFeatures } from '../utils/platformUi';
import CommandModal from './CommandModal';
import NotificationPanel from './NotificationPanel';
import PreviewModeMenu from './layout/PreviewModeMenu';
import EntitlementPreviewPanel from './layout/EntitlementPreviewPanel';
import { PlannerLogo } from './MonefyiLogo';
import { EstimatorLogo } from './EstimatorLogo';
import { shouldShowEstimatorProductBrand } from '../lib/appProductBrand';
import { ESTIMATOR_THEME_COLOR } from '../lib/estimatorBrand';
import ToastHost from './ToastHost';
import EstimatorLaunchPromoAdminModal from './admin/EstimatorLaunchPromoAdminModal';
import UndoToast from './ui/UndoToast';
import { loadFinanceVersion } from '../lib/financeVersion';
import { loadMigrationFlags } from '../lib/migrationFlags';
import { DEFAULT_MIGRATION_FLAGS } from '../types/rpp';
import { useOrgBrand } from '../hooks/useOrgBrand';
import { MONEFYI_BRAND } from '../lib/orgBrand';
import RightPanel from './layout/RightPanel';
import { useShellStore } from '../store/shellStore';
import { useEntitlement } from '../hooks/useEntitlement';
import UpgradeModal from './entitlement/UpgradeModal';
import type { UpgradeModalTrigger } from '../types/entitlement';
import { analytics } from '../lib/analytics/events';
import { applyEstimatorDocumentBrand } from '../lib/estimatorBrand';
import { isAdminFullAccess, canAccessPlannerNavModule, plannerNavModuleLabel, isEstimatorOnlyPlan, type PlannerNavModule } from '../lib/entitlement';
import UserMenuDropdown from './estimator/shell/UserMenuDropdown';
import EstimatorBottomNavItem from './estimator/shell/EstimatorBottomNavItem';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const {
    user, tenant, activeTab, setActiveTab, setFinanceVersionPreference,
    migrationFlags, setMigrationFlags,
    syncStatus, pendingSyncCount, isOnline, lastSynced, unreadCount, commandModalOpen,
    setCommandModalOpen, sidebarOpen, setSidebarOpen, navSidebarCollapsed, toggleNavSidebarCollapsed,
    rightPanelHidden, toggleRightPanelHidden,
    platformRole, uiViewMode, entitlementPreviewMode,
  } = useAppStore();
  const navigate = useNavigate();
  const location = useLocation();

  const [notifOpen, setNotifOpen] = useState(false);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [upgradeTrigger, setUpgradeTrigger] = useState<UpgradeModalTrigger>('pro_feature');
  const [upgradeFeatureName, setUpgradeFeatureName] = useState<string | undefined>();
  const entitlement = useEntitlement();
  const { isLoading: entitlementLoading } = entitlement;

  useEffect(() => {
    if (!user?.id) return;
    loadFinanceVersion(user.id)
      .then(setFinanceVersionPreference)
      .catch(() => setFinanceVersionPreference('v3'));
    loadMigrationFlags(user.id)
      .then(setMigrationFlags)
      .catch(() => setMigrationFlags({ ...DEFAULT_MIGRATION_FLAGS }));
  }, [user?.id, setFinanceVersionPreference, setMigrationFlags]);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) setMigrationFlags(detail);
    };
    window.addEventListener('monefyi:migration-flags-changed', handler);
    return () => window.removeEventListener('monefyi:migration-flags-changed', handler);
  }, [setMigrationFlags]);

  const { style: orgBrandStyle } = useOrgBrand(tenant?.brandColor);
  const isSuperAdmin = isPlatformAdmin(platformRole, user?.email);
  const adminFullAccess = isAdminFullAccess(platformRole, user?.email, entitlementPreviewMode);
  const estimatorOnly = !adminFullAccess && isEstimatorOnlyPlan(entitlement);
  const isWorker = showWorkerShell(user?.role, platformRole, user?.email, uiViewMode);
  const canAccessHr = canAccessManagerFeatures(user?.role, platformRole, user?.email, uiViewMode);
  const isEstimatorShell = location.pathname.startsWith('/app/estimator');
  const hideMobileProductNav = estimatorOnly && isEstimatorShell;
  const showEstimatorBrand =
    !adminFullAccess && shouldShowEstimatorProductBrand(entitlement);

  useEffect(() => {
    if (entitlementLoading) return;
    applyEstimatorDocumentBrand(showEstimatorBrand);
    return () => {
      if (showEstimatorBrand) applyEstimatorDocumentBrand(false);
    };
  }, [showEstimatorBrand, entitlementLoading]);

  const ownerMobileTabs = estimatorOnly
    ? [
      { id: 'projects', label: 'Proyek', icon: FolderOpen },
      { id: 'estimator', label: 'Estimator', icon: Receipt },
    ]
    : [
      { id: 'home', label: 'Home', icon: Home },
      { id: 'projects', label: 'Proyek', icon: FolderOpen },
      { id: 'command', label: '✦', icon: Sparkles, special: true },
      { id: 'estimator', label: 'Estimator', icon: Receipt },
      { id: 'finance', label: 'Finance', icon: Wallet },
    ];

  const workerTabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'attendance', label: 'Absensi', icon: Clock },
    { id: 'command', label: '✦', icon: Sparkles, special: true },
    { id: 'payroll', label: 'Payroll', icon: Wallet },
    { id: 'todos', label: 'Todolist', icon: BarChart3 },
  ];

  const mobileTabs = isWorker ? workerTabs : ownerMobileTabs;

  const isTabActive = (tabId: string) => {
    if (tabId === 'projects') {
      return activeTab === 'projects' || location.pathname.startsWith('/app/projects/');
    }
    if (tabId === 'estimator') return location.pathname.startsWith('/app/estimator');
    if (tabId === 'finance') {
      return activeTab === 'finance' || location.pathname.startsWith('/app/finance-v2');
    }
    if (tabId === 'database') {
      return location.pathname.startsWith('/app/database');
    }
    if (tabId === 'home') {
      return activeTab === 'home'
        && !location.pathname.startsWith('/app/estimator')
        && !location.pathname.startsWith('/app/finance-v2')
        && !location.pathname.startsWith('/app/database');
    }
    return activeTab === tabId;
  };

  const ownerSidebarItems = estimatorOnly
    ? [
      { id: 'projects', label: 'Proyek', icon: FolderOpen },
      { id: 'estimator', label: 'Estimator', icon: Receipt },
    ]
    : [
      { id: 'home', label: 'Dashboard', icon: Home },
      { id: 'projects', label: 'Proyek', icon: FolderOpen },
      { id: 'database', label: 'Database', icon: Database },
      { id: 'estimator', label: 'Estimator', icon: Receipt },
      { id: 'finance', label: 'Keuangan Bisnis', icon: Wallet },
      ...(canAccessHr
        ? [{ id: 'hr', label: 'HR & Karyawan', icon: Users }]
        : []),
    ];

  const workerSidebarItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'attendance', label: 'Absensi', icon: Clock },
    { id: 'payroll', label: 'Payroll', icon: Wallet },
    { id: 'todos', label: 'Todo', icon: BarChart3 },
  ];

  const sidebarItems = isWorker ? workerSidebarItems : ownerSidebarItems;

  const navigationGuard = useUiStore(s => s.navigationGuard);

  const openUpgrade = (trigger: UpgradeModalTrigger, featureName?: string) => {
    setUpgradeTrigger(trigger);
    setUpgradeFeatureName(featureName);
    setUpgradeOpen(true);
  };

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ trigger?: UpgradeModalTrigger; featureName?: string }>).detail;
      openUpgrade(detail?.trigger ?? 'pro_feature', detail?.featureName);
    };
    window.addEventListener('monefyi:open-upgrade', handler);
    return () => window.removeEventListener('monefyi:open-upgrade', handler);
  }, []);

  const isNavLocked = (tabId: string) => {
    if (adminFullAccess || entitlementLoading) return false;
    const module = tabId as PlannerNavModule;
    if (['home', 'projects', 'database', 'estimator', 'finance', 'hr'].includes(tabId)) {
      return !canAccessPlannerNavModule(entitlement, module);
    }
    return false;
  };

  const navigateToTab = async (tabId: string) => {
    if (navigationGuard) {
      const canLeave = await navigationGuard.promptLeave();
      if (!canLeave) return;
    }

    const plannerModule = tabId as PlannerNavModule;
    if (
      !adminFullAccess
      && ['home', 'projects', 'database', 'estimator', 'finance', 'hr'].includes(tabId)
      && !canAccessPlannerNavModule(entitlement, plannerModule)
    ) {
      if (tabId === 'estimator' && !entitlement.isEstimator) {
        openUpgrade('estimator_paywall', plannerNavModuleLabel(plannerModule));
      } else {
        analytics.proFeatureClicked({ featureName: plannerNavModuleLabel(plannerModule) });
        openUpgrade('pro_feature', plannerNavModuleLabel(plannerModule));
      }
      setSidebarOpen(false);
      return;
    }

    if (tabId === 'estimator') {
      setActiveTab('estimator');
      navigate('/app/estimator');
    } else if (tabId === 'database') {
      setActiveTab('database');
      navigate('/app/database');
    } else if (tabId === 'finance') {
      setActiveTab('finance');
      navigate('/app/finance-v2');
    } else {
      navigate('/app');
      setActiveTab(tabId);
    }
    setSidebarOpen(false);
  };

  const handleNav = navigateToTab;

  const goSettingsTab = async (st: string) => {
    if (navigationGuard) {
      const canLeave = await navigationGuard.promptLeave();
      if (!canLeave) return;
    }
    if (estimatorOnly) {
      openUpgrade('pro_feature', 'Pengaturan');
      return;
    }
    setActiveTab('settings');
    navigate(`/app?tab=settings&st=${st}`);
    setSidebarOpen(false);
  };

  const openCommandModal = () => {
    if (estimatorOnly) {
      openUpgrade('pro_feature', 'Monefyi AI');
      return;
    }
    setCommandModalOpen(true);
  };

  const getSyncIndicator = () => {
    switch (syncStatus) {
      case 'synced': return { color: 'bg-emerald-500', text: 'Tersinkron', textColor: 'text-emerald-700', bg: 'bg-emerald-50' };
      case 'syncing': return { color: 'bg-amber-500 animate-pulse', text: 'Menyinkron...', textColor: 'text-amber-700', bg: 'bg-amber-50' };
      case 'offline': return { color: 'bg-slate-400', text: `Offline${pendingSyncCount > 0 ? ` · ${pendingSyncCount} item` : ''}`, textColor: 'text-slate-600', bg: 'bg-slate-100/80' };
      case 'error': return { color: 'bg-rose-500', text: 'Sync error', textColor: 'text-rose-700', bg: 'bg-rose-50' };
    }
  };

  const sync = getSyncIndicator();
  const lastSyncText = lastSynced ? `${Math.floor((Date.now() - lastSynced.getTime()) / 60000)} mnt lalu` : 'Belum pernah';

  const userMenuItems = [
    {
      id: 'profile',
      label: 'Profil saya',
      icon: <User className="w-4 h-4 shrink-0" />,
      onClick: () => goSettingsTab('profil'),
    },
    ...(isEstimatorShell ? [{
      id: 'estimator-settings',
      label: 'Pengaturan Estimator',
      icon: <Settings className="w-4 h-4 shrink-0" />,
      onClick: () => navigate('/app/estimator/settings'),
    }] : []),
    {
      id: 'settings',
      label: 'Pengaturan',
      icon: <Settings className="w-4 h-4 shrink-0" />,
      onClick: () => goSettingsTab('organisasi'),
    },
    ...(isSuperAdmin ? [{
      id: 'admin',
      label: 'Super Admin',
      icon: <Shield className="w-4 h-4 shrink-0" />,
      onClick: () => navigate('/admin'),
    }] : []),
  ];

  const showRightPanel =
    /^\/app\/projects\/[^/]+$/.test(location.pathname)
    || location.pathname.startsWith('/app/finance-v2')
    || location.pathname.startsWith('/app/database');

  const {
    breadcrumb,
    projectId: shellProjectId,
    hideRightPanel,
    onOpenRap,
    onOpenProgress,
    estimatorCode,
    onEstimatorBack,
  } = useShellStore();
  const isEstimatorDetail = /^\/app\/estimator\/(?!pricelist(?:\/|$)|settings(?:\/|$)).+/.test(location.pathname);

  const headerTitle = (() => {
    if (breadcrumb.length > 0) {
      return breadcrumb.map((b, i) => (
        <span key={i} className="flex items-center gap-1.5">
          {i > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-400" />}
          <span className={i === breadcrumb.length - 1 ? 'text-slate-800' : 'text-slate-500'}>{b.label}</span>
        </span>
      ));
    }
    if (location.pathname.startsWith('/app/finance-v2')) return 'Keuangan Bisnis';
    if (location.pathname.startsWith('/app/database')) return 'Database Master';
    const title = activeTab === 'home' ? 'Dashboard'
      : activeTab === 'projects' ? 'Manajemen Proyek'
        : activeTab === 'estimator' ? 'Estimator'
          : activeTab === 'finance' ? 'Keuangan'
            : activeTab === 'hr' ? 'HR & Karyawan'
              : activeTab === 'settings' ? 'Pengaturan' : activeTab;
    return title;
  })();

  return (
    <div className="flex h-screen overflow-hidden org-branded" style={orgBrandStyle}>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col shell-sidebar z-30 transition-[width] duration-200 shrink-0 ${
          navSidebarCollapsed ? 'w-[4.5rem]' : 'w-64'
        }`}
      >
        {/* Logo + collapse + Monefyi AI */}
        <div className={`${navSidebarCollapsed ? 'px-2 py-3' : 'p-4'}`}>
          <div className={`flex items-center gap-2 ${navSidebarCollapsed ? 'flex-col' : ''}`}>
            {showEstimatorBrand ? (
              <EstimatorLogo className="rounded-xl object-contain shadow-md shrink-0 w-9 h-9" />
            ) : (
              <PlannerLogo
                className={`rounded-xl object-contain shadow-md shrink-0 ${
                  navSidebarCollapsed ? 'w-9 h-9' : 'w-9 h-9'
                }`}
              />
            )}
            {!navSidebarCollapsed && (
              <div className="flex-1 min-w-0">
                <div
                  className="font-black text-sm leading-tight"
                  style={{ color: showEstimatorBrand ? ESTIMATOR_THEME_COLOR : MONEFYI_BRAND.dark }}
                >
                  {showEstimatorBrand ? 'Estimator' : 'Planner'}
                </div>
              </div>
            )}
            <button
              type="button"
              onClick={toggleNavSidebarCollapsed}
              className={`p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors shrink-0 ${
                navSidebarCollapsed ? 'mt-1' : ''
              }`}
              title={navSidebarCollapsed ? 'Perluas menu' : 'Perkecil menu'}
              aria-label={navSidebarCollapsed ? 'Perluas menu navigasi' : 'Perkecil menu navigasi'}
            >
              <ChevronRight
                className={`w-5 h-5 transition-transform duration-200 ${
                  navSidebarCollapsed ? 'rotate-180' : ''
                }`}
              />
            </button>
          </div>

          <button
            type="button"
            onClick={openCommandModal}
            className={`mt-3 relative flex items-center justify-center shadow-md hover:opacity-95 transition-all ${
              navSidebarCollapsed
                ? 'w-10 h-10 mx-auto rounded-xl'
                : 'w-full h-11 rounded-xl gap-2'
            }`}
            style={{ background: `linear-gradient(135deg, ${MONEFYI_BRAND.primary}, ${MONEFYI_BRAND.dark})` }}
            aria-label="Buka Monefyi AI"
            title="Monefyi AI"
          >
            <Sparkles className="w-5 h-5 text-white shrink-0" />
            {!navSidebarCollapsed && (
              <span className="text-sm font-bold text-white">Monefyi AI</span>
            )}
            {pendingSyncCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {pendingSyncCount > 9 ? '9+' : pendingSyncCount}
              </span>
            )}
          </button>

          {tenant && !navSidebarCollapsed && (
            <div className="mt-3 px-2 py-1.5 bg-org-soft rounded-xl">
              <div className="flex items-center gap-2 min-w-0">
                {tenant.logo ? (
                  <img src={tenant.logo} alt="" className="w-6 h-6 rounded object-cover shrink-0" />
                ) : (
                  <div className="w-6 h-6 rounded bg-org-primary shrink-0 flex items-center justify-center text-[10px] font-bold text-org-on-primary">
                    {tenant.name.charAt(0)}
                  </div>
                )}
                <div className="min-w-0">
                  <div className="text-xs font-medium text-slate-700 truncate">{tenant.name}</div>
                  <div className="text-xs text-slate-600 capitalize">{tenant.plan} plan</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Nav Items */}
        <nav className={`flex-1 overflow-y-auto space-y-1 ${navSidebarCollapsed ? 'p-2' : 'p-4'}`}>
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              title={navSidebarCollapsed ? item.label : undefined}
              className={`w-full flex items-center rounded-xl text-sm font-medium transition-all relative ${
                navSidebarCollapsed
                  ? 'justify-center p-2.5'
                  : 'gap-3 px-3 py-2.5'
              } ${
                isTabActive(item.id)
                  ? 'bg-org-soft text-org-dark shadow-sm'
                  : 'text-slate-600 hover:bg-white/70 hover:text-slate-900'
              }`}
            >
              <item.icon className={`shrink-0 ${navSidebarCollapsed ? 'w-5 h-5' : 'w-4.5 h-4.5'} ${
                isTabActive(item.id) ? 'text-org-primary' : 'text-slate-600'
              }`} />
              {!navSidebarCollapsed && (
                <>
                  <span className="truncate">{item.label}</span>
                  {isNavLocked(item.id) && (
                    <Lock className="w-3.5 h-3.5 text-slate-400 ml-auto shrink-0" />
                  )}
                  {item.id === 'home' && unreadCount > 0 && (
                    <span className={`${isNavLocked(item.id) ? '' : 'ml-auto'} px-1.5 py-0.5 bg-rose-500 text-white text-xs font-bold rounded-full`}>
                      {unreadCount}
                    </span>
                  )}
                </>
              )}
              {navSidebarCollapsed && item.id === 'home' && unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full" />
              )}
            </button>
          ))}
        </nav>

        {isSuperAdmin && (
          <EntitlementPreviewPanel collapsed={navSidebarCollapsed} />
        )}
      </aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-72 bg-white z-50 shadow-2xl lg:hidden flex flex-col"
            >
              <div className="p-6 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {showEstimatorBrand ? (
                    <EstimatorLogo className="w-9 h-9 rounded-xl object-contain" />
                  ) : (
                    <PlannerLogo className="w-9 h-9 rounded-xl object-contain" />
                  )}
                  <div>
                    <div
                      className="font-black"
                      style={{ color: showEstimatorBrand ? ESTIMATOR_THEME_COLOR : undefined }}
                    >
                      {showEstimatorBrand ? 'Estimator' : 'Planner'}
                    </div>
                  </div>
                </div>
                <button onClick={() => setSidebarOpen(false)} className="p-2 rounded-lg hover:bg-slate-100">
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>

              <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
                {sidebarItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNav(item.id)}
                    className={`w-full min-h-11 flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all ${
                      isTabActive(item.id)
                        ? 'bg-org-soft text-org-dark'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                    {isNavLocked(item.id) && (
                      <Lock className="w-3.5 h-3.5 text-slate-400 ml-auto" />
                    )}
                  </button>
                ))}
                {isEstimatorShell && (
                  <button
                    type="button"
                    onClick={() => {
                      navigate('/app/estimator/settings');
                      setSidebarOpen(false);
                    }}
                    className="w-full min-h-11 flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50"
                  >
                    <Settings className="w-5 h-5" />
                    Pengaturan Estimator
                  </button>
                )}
              </nav>

              {isSuperAdmin && <EntitlementPreviewPanel />}

            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className={`shell-header px-4 lg:px-6 h-14 flex items-center justify-between shrink-0 z-20 ${
          isEstimatorShell ? 'lg:hidden bg-white/80 backdrop-blur-md border-b border-slate-100' : ''
        }`}>
          <div className="flex items-center gap-2 min-w-0">
            {isEstimatorDetail ? (
              <button
                type="button"
                onClick={() => onEstimatorBack?.() ?? navigate('/app/estimator')}
                className="inline-flex items-center justify-center min-h-11 min-w-11 rounded-lg hover:bg-slate-100 lg:hidden transition-colors active:scale-95"
                aria-label="Kembali ke daftar estimasi"
              >
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </button>
            ) : (
              <button
                onClick={() => setSidebarOpen(true)}
                className="inline-flex items-center justify-center min-h-11 min-w-11 rounded-lg hover:bg-slate-100 lg:hidden transition-colors active:scale-95"
                aria-label="Buka menu"
              >
                <Menu className="w-5 h-5 text-slate-600" />
              </button>
            )}
            <div className="hidden lg:block">
              <div className="text-sm font-semibold capitalize flex items-center flex-wrap gap-0.5">
                {headerTitle}
              </div>
            </div>
            {isEstimatorDetail ? (
              <div className="lg:hidden min-w-0">
                {estimatorCode && (
                  <span className="inline-flex items-center min-h-8 px-2.5 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-bold font-mono truncate max-w-[11rem]">
                    {estimatorCode}
                  </span>
                )}
              </div>
            ) : isEstimatorShell ? (
              <div className="lg:hidden flex items-center gap-2 min-w-0">
                {showEstimatorBrand ? (
                  <EstimatorLogo className="w-7 h-7 rounded-lg object-contain shrink-0" />
                ) : (
                  <PlannerLogo className="w-7 h-7 rounded-lg object-contain shrink-0" />
                )}
                <span className="font-bold text-slate-900 text-sm truncate">
                  {showEstimatorBrand ? 'Estimator' : 'Planner'}
                </span>
                <span
                  className={`w-2 h-2 rounded-full shrink-0 ${sync.color}`}
                  title={sync.text}
                  aria-label={sync.text}
                />
              </div>
            ) : (
              <div className="lg:hidden flex items-center gap-2">
                {showEstimatorBrand ? (
                  <EstimatorLogo className="w-7 h-7 rounded-lg object-contain" />
                ) : (
                  <PlannerLogo className="w-7 h-7 rounded-lg object-contain" />
                )}
                <span className="font-bold text-slate-900 text-sm">
                  {showEstimatorBrand ? 'Estimator' : 'Planner'}
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isEstimatorShell ? (
              <>
                <div className="relative lg:hidden">
                  <button
                    onClick={() => setNotifOpen(!notifOpen)}
                    className="relative inline-flex items-center justify-center min-h-11 min-w-11 rounded-xl hover:bg-slate-100 transition-all duration-200 active:scale-95"
                    aria-label="Notifikasi"
                  >
                    <Bell className="w-5 h-5 text-slate-600" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </button>
                  <AnimatePresence>
                    {notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}
                  </AnimatePresence>
                </div>
                <div className="lg:hidden">
                  <UserMenuDropdown userName={user?.name} items={userMenuItems} />
                </div>
              </>
            ) : (
              <>
            {/* Sync Status — desktop & tablet */}
            <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${sync.bg} ${sync.textColor}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${sync.color}`} />
              <span className="hidden sm:block">{sync.text}</span>
              <span className="hidden lg:inline text-slate-600 font-normal">· {lastSyncText}</span>
              {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            </div>

            {/* Notifications */}
            {showRightPanel && (
              <button
                type="button"
                onClick={toggleRightPanelHidden}
                className="hidden xl:flex p-2 rounded-xl hover:bg-slate-100 transition-colors"
                title={rightPanelHidden ? 'Tampilkan panel kanan' : 'Sembunyikan panel kanan'}
                aria-label={rightPanelHidden ? 'Tampilkan panel kanan' : 'Sembunyikan panel kanan'}
              >
                {rightPanelHidden
                  ? <PanelRight className="w-5 h-5 text-slate-600" />
                  : <PanelRightClose className="w-5 h-5 text-slate-600" />}
              </button>
            )}
            <div className="relative">
              <button
                onClick={() => setNotifOpen(!notifOpen)}
                className="relative p-2 rounded-xl hover:bg-slate-100 transition-colors"
              >
                <Bell className="w-5 h-5 text-slate-600" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </button>
              <AnimatePresence>
                {notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}
              </AnimatePresence>
            </div>

            {isSuperAdmin && <PreviewModeMenu />}

            {isSuperAdmin && (
              <button
                type="button"
                onClick={() => navigate('/admin')}
                className="p-2 rounded-xl hover:bg-slate-100 text-slate-600 transition-colors"
                aria-label="Super Admin"
                title="Super Admin"
              >
                <Shield className="w-5 h-5" />
              </button>
            )}

            <button
              type="button"
              onClick={() => goSettingsTab('organisasi')}
              className="p-2 rounded-xl hover:bg-slate-100 transition-colors"
              aria-label="Pengaturan organisasi"
              title="Pengaturan organisasi"
            >
              <Settings className="w-5 h-5 text-slate-600" />
            </button>

            <button
              type="button"
              onClick={() => goSettingsTab('profil')}
              className="w-8 h-8 rounded-full bg-org-primary flex items-center justify-center text-org-on-primary text-xs font-bold shrink-0"
              aria-label="Profil saya"
              title={user?.name || 'Profil'}
            >
              {user?.name.charAt(0) || 'U'}
            </button>
              </>
            )}
          </div>
        </header>

        {/* Desktop header for estimator shell */}
        {isEstimatorShell && (
          <header className="hidden lg:flex shell-header px-6 h-14 items-center justify-between shrink-0 z-20">
            <div className="text-sm font-semibold capitalize flex items-center flex-wrap gap-0.5">
              {headerTitle}
            </div>
            <div className="flex items-center gap-2">
              <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${sync.bg} ${sync.textColor}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${sync.color}`} />
                <span>{sync.text}</span>
                <span className="text-slate-600 font-normal">· {lastSyncText}</span>
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
              </div>
              <div className="relative">
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  className="relative p-2 rounded-xl hover:bg-slate-100 transition-colors"
                >
                  <Bell className="w-5 h-5 text-slate-600" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-rose-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </button>
                <AnimatePresence>
                  {notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}
                </AnimatePresence>
              </div>
              {isSuperAdmin && <PreviewModeMenu />}
              {isSuperAdmin && (
                <button type="button" onClick={() => navigate('/admin')} className="p-2 rounded-xl hover:bg-slate-100 text-slate-600" aria-label="Super Admin">
                  <Shield className="w-5 h-5" />
                </button>
              )}
              <button type="button" onClick={() => goSettingsTab('organisasi')} className="p-2 rounded-xl hover:bg-slate-100" aria-label="Pengaturan">
                <Settings className="w-5 h-5 text-slate-600" />
              </button>
              <button type="button" onClick={() => goSettingsTab('profil')} className="w-8 h-8 rounded-full bg-org-primary flex items-center justify-center text-org-on-primary text-xs font-bold">
                {user?.name.charAt(0) || 'U'}
              </button>
            </div>
          </header>
        )}

        {/* Page Content + Right Panel */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          <main className="flex-1 overflow-y-auto min-w-0">
            {children}
          </main>
          {showRightPanel && !hideRightPanel && !rightPanelHidden && (
            <RightPanel
              projectId={shellProjectId}
              onOpenRap={onOpenRap ?? undefined}
              onOpenProgress={onOpenProgress ?? undefined}
            />
          )}
          {showRightPanel && !hideRightPanel && rightPanelHidden && (
            <button
              type="button"
              onClick={toggleRightPanelHidden}
              className="hidden xl:flex fixed right-0 top-1/2 -translate-y-1/2 z-20 items-center gap-1 pl-2 pr-1.5 py-3 rounded-l-xl bg-white border border-r-0 border-slate-200 shadow-md text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 transition-colors"
              title="Tampilkan panel kanan"
              aria-label="Tampilkan panel kanan"
            >
              <PanelRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Bottom Navigation — Mobile (Estimator-only: sembunyikan di shell Estimator) */}
        {!hideMobileProductNav && (
        <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-lg border-t border-slate-100 safe-bottom shrink-0 shadow-[0_-4px_24px_rgba(15,23,42,0.06)]">
          <div className="flex items-center justify-around h-16 px-2">
            {mobileTabs.map((tab) => (
              tab.special ? (
                <button
                  key={tab.id}
                  onClick={openCommandModal}
                  className="relative -mt-6 flex flex-col items-center active:scale-95 transition-all duration-200"
                >
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-xl shadow-emerald-300/40 animate-breathe relative">
                    <Sparkles className="w-6 h-6 text-white" />
                    {pendingSyncCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                        {pendingSyncCount > 9 ? '9+' : pendingSyncCount}
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-emerald-600 font-bold mt-1">Monefyi</span>
                </button>
              ) : showEstimatorBrand ? (
                <EstimatorBottomNavItem
                  key={tab.id}
                  icon={tab.icon}
                  label={tab.label}
                  active={isTabActive(tab.id)}
                  locked={isNavLocked(tab.id)}
                  onClick={() => handleNav(tab.id)}
                />
              ) : (
                <button
                  key={tab.id}
                  onClick={() => handleNav(tab.id)}
                  className={`flex flex-col items-center gap-0.5 px-3 py-1 transition-all duration-200 rounded-xl active:scale-95 ${
                    isTabActive(tab.id)
                      ? 'text-emerald-600 bg-emerald-50'
                      : 'text-slate-600 hover:text-slate-800'
                  }`}
                >
                  <tab.icon className="w-5 h-5" />
                  <span className={`text-[10px] font-semibold flex items-center gap-0.5 ${isTabActive(tab.id) ? 'font-bold' : ''}`}>
                    {tab.label}
                    {isNavLocked(tab.id) && <Lock className="w-2.5 h-2.5" />}
                  </span>
                </button>
              )
            ))}
          </div>
        </nav>
        )}
      </div>

      {/* Command Modal */}
      <AnimatePresence>
        {commandModalOpen && <CommandModal />}
      </AnimatePresence>
      <ToastHost />
      <EstimatorLaunchPromoAdminModal />
      <UndoToast />
      <UpgradeModal
        open={upgradeOpen}
        trigger={upgradeTrigger}
        featureName={upgradeFeatureName}
        onClose={() => {
          setUpgradeOpen(false);
          setUpgradeFeatureName(undefined);
        }}
        onManageProjects={() => navigate('/app?tab=projects')}
      />
    </div>
  );
}
