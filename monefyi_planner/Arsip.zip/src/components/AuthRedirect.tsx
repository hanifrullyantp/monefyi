import { Navigate, useLocation } from 'react-router-dom';
import { useAppStore } from '../store/appStore';
import { isPlatformAdmin } from '../services/adminService';
import { estimatorAppEntryPath, initEstimatorPwaDocument } from '../lib/pwaBrand';
import { isEstimatorBrandContext } from '../lib/estimatorBrand';

const MEMBERSHIP_SETUP_PATHS = [
  '/signup/owner',
  '/find-company',
  '/join',
  '/join-by-code',
  '/verify-email',
  '/onboarding/owner',
  '/onboarding/member',
];

export default function AuthRedirect() {
  const { isAuthenticated, authInitializing, platformRole, user, hasMembership } = useAppStore();
  const location = useLocation();
  if (authInitializing) return null;

  initEstimatorPwaDocument();

  if (isAuthenticated) {
    if (!hasMembership && !isPlatformAdmin(platformRole, user?.email)) {
      if (MEMBERSHIP_SETUP_PATHS.some(path => location.pathname.startsWith(path))) {
        return null;
      }
    }

    const guestOnlyPaths = ['/', '/signup'];
    if (guestOnlyPaths.includes(location.pathname)) {
      const dest = isEstimatorBrandContext() ? estimatorAppEntryPath() : '/app';
      return <Navigate to={dest} replace />;
    }

    if (location.pathname === '/signup/owner' && hasMembership) {
      return <Navigate to={isEstimatorBrandContext() ? estimatorAppEntryPath() : '/app'} replace />;
    }
  }

  return null;
}
