import { Fragment, useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react';
import { Plus, Trash2, Sparkles, List, ChevronDown } from 'lucide-react';
import { calcEstimationSummary, calcItemRow, countedEstimationItems, effectiveItemSelling, emptyItem, sellingFromHpp, syncEstimationItemPricesList, estimationItemsNeedPriceSync, type ItemPriceEdit } from '../../lib/estimatorCalc';
import { formatRupiahFull, parseNumberId } from '../../lib/estimatorFormat';
import {
  getEstimationItemProductGroup,
  groupEstimationItemsByProduct,
  groupSharedQty,
  hasProductGroup,
  type EstimationItemGroup,
} from '../../lib/estimatorProductGroup';
import type { ParsedEstimationItem } from '../../lib/estimatorParser';
import type { EstimationAdjustment, EstimationItemDraft } from '../../types/estimator';
import type { PricelistItem } from '../../types/estimator';
import { COMMON_UNITS, pricelistToEstimationItem, PRICELIST_CATEGORIES } from '../../services/pricelistService';
import { ENABLE_ESTIMATOR_SMART_INPUT } from '../../lib/estimatorFeatureFlags';
import RupiahInput from './RupiahInput';
import QtyInput from './QtyInput';
import SmartInputModal from './SmartInputModal';
import PricelistPickerModal from './PricelistPickerModal';
import { useUiStore } from '../../store/uiStore';
import { estimationItemDisplayName, uniquifyItemName } from '../../lib/estimatorItemDisplayName';

function GlobalQtyField({
  className,
  onApply,
}: {
  className: string;
  onApply: (qty: number) => void;
}) {
  const [text, setText] = useState('');
  return (
    <input
      type="text"
      inputMode="decimal"
      value={text}
      placeholder="Qty"
      aria-label="Ukuran global"
      onMouseUp={e => e.preventDefault()}
      onFocus={e => e.currentTarget.select()}
      onChange={e => {
        const raw = e.target.value;
        setText(raw);
        if (!raw.trim() || !/^[\d.,]+$/.test(raw.trim())) return;
        const qty = parseNumberId(raw);
        if (Number.isFinite(qty) && qty >= 0) onApply(qty);
      }}
      className={className}
    />
  );
}

function selectNumericField(event: { currentTarget: HTMLInputElement }) {
  event.currentTarget.select();
}

type EditableField = 'name' | 'qty' | 'selling' | 'margin' | 'hpp';

interface Props {
  orgId: string;
  userId?: string;
  items: EstimationItemDraft[];
  defaultMargin?: number;
  overheadPct?: number;
  discountPct?: number;
  discountAmount?: number;
  adjustments?: EstimationAdjustment[];
  taxPct?: number;
  billingDiscountAmount?: number;
  billingBonusNote?: string;
  onChange: (items: EstimationItemDraft[]) => void;
  readOnly?: boolean;
  onRegisterAddItem?: (add: () => void) => void;
}

export default function EstimationItemsTable({
  orgId,
  userId = '',
  items,
  defaultMargin = 20,
  overheadPct = 0,
  discountPct = 0,
  discountAmount = 0,
  adjustments = [],
  taxPct = 0,
  billingDiscountAmount = 0,
  billingBonusNote = '',
  onChange,
  readOnly = false,
  onRegisterAddItem,
}: Props) {
  const [smartOpen, setSmartOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [equalizeOpen, setEqualizeOpen] = useState(false);
  const showToast = useUiStore(s => s.showToast);
  const cellRefs = useRef<Map<string, HTMLInputElement | HTMLSelectElement>>(new Map());

  // Perbaiki HPP yang tidak selaras dengan margin (data lama / formula markup).
  useEffect(() => {
    const synced = syncEstimationItemPricesList(items);
    if (!estimationItemsNeedPriceSync(items, synced)) return;
    onChange(synced);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- sinkron harga saat items berubah
  }, [items]);

  const namedItems = useMemo(() => items.filter(i => i.name.trim()), [items]);
  const countedItems = useMemo(() => countedEstimationItems(items), [items]);
  const productGroups = useMemo(() => groupEstimationItemsByProduct(items), [items]);
  const groupHeaderAt = useMemo(() => {
    const map = new Map<number, EstimationItemGroup>();
    for (const g of productGroups) {
      if (g.indices.length) map.set(Math.min(...g.indices), g);
    }
    return map;
  }, [productGroups]);
  const totals = useMemo(
    () => calcEstimationSummary(countedItems, overheadPct, discountPct, taxPct, {
      discountAmount,
      adjustments,
      billingDiscountAmount,
      billingBonusNote,
    }),
    [countedItems, overheadPct, discountPct, discountAmount, adjustments, taxPct, billingDiscountAmount, billingBonusNote],
  );

  const updateItem = (index: number, patch: Partial<EstimationItemDraft>, editField: ItemPriceEdit = 'selling') => {
    if (readOnly) return;
    const next = [...items];
    const merged = { ...next[index], ...patch };
    const calc = calcItemRow(merged, editField);
    const row = { ...merged, ...calc };
    row.total_profit = effectiveItemSelling(row) - (Number(row.total_hpp) || 0);
    next[index] = row;
    onChange(next);
  };

  const addRow = useCallback(() => {
    if (readOnly) return;
    onChange([...items, emptyItem(items.length)]);
  }, [readOnly, items, onChange]);

  const openPricelistPicker = useCallback(() => {
    if (readOnly) return;
    setPickerOpen(true);
  }, [readOnly]);

  useEffect(() => {
    onRegisterAddItem?.(openPricelistPicker);
  }, [onRegisterAddItem, openPricelistPicker]);
  const removeRow = (index: number) => {
    if (readOnly) return;
    const label = items[index]?.name?.trim() || 'item ini';
    if (!window.confirm(`Hapus ${label}?`)) return;
    onChange(items.filter((_, i) => i !== index));
    setExpandedIndex(prev => {
      if (prev == null) return prev;
      if (prev === index) return null;
      return prev > index ? prev - 1 : prev;
    });
  };

  const applyGlobalQty = (qty: number) => {
    if (readOnly || !Number.isFinite(qty) || qty < 0) return;
    onChange(items.map(item => {
      const merged = { ...item, qty };
      const calc = calcItemRow(merged, 'qty');
      const row = { ...merged, ...calc };
      row.total_profit = effectiveItemSelling(row) - (Number(row.total_hpp) || 0);
      return row;
    }));
  };

  const toggleRowExpanded = (index: number) => {
    setExpandedIndex(prev => (prev === index ? null : index));
  };

  const shouldShowGroupHeader = (group: EstimationItemGroup) =>
    group.indices.length > 1 ||
    (group.indices.length === 1 && hasProductGroup(items[group.indices[0]]));

  const setGroupQty = (indices: number[], qty: number) => {
    if (readOnly) return;
    const next = [...items];
    for (const idx of indices) {
      const merged = { ...next[idx], qty };
      const calc = calcItemRow(merged, 'qty');
      const row = { ...merged, ...calc };
      row.total_profit = effectiveItemSelling(row) - (Number(row.total_hpp) || 0);
      next[idx] = row;
    }
    onChange(next);
  };

  const focusCell = (row: number, field: EditableField) => {
    cellRefs.current.get(`${row}-${field}`)?.focus();
  };

  const handleKeyDown = (
    e: KeyboardEvent,
    row: number,
    field: EditableField,
    fields: EditableField[],
  ) => {
    if (e.key === 'Tab' && !e.shiftKey) {
      e.preventDefault();
      const idx = fields.indexOf(field);
      if (idx < fields.length - 1) {
        focusCell(row, fields[idx + 1]);
      } else if (row < items.length - 1) {
        focusCell(row + 1, fields[0]);
      } else {
        addRow();
        setTimeout(() => focusCell(row + 1, fields[0]), 0);
      }
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      if (row < items.length - 1) {
        focusCell(row + 1, field);
      } else {
        addRow();
        setTimeout(() => focusCell(row + 1, field), 0);
      }
    }
  };

  const registerRef = (key: string) => (el: HTMLInputElement | HTMLSelectElement | null) => {
    if (el) cellRefs.current.set(key, el);
    else cellRefs.current.delete(key);
  };

  const handleSmartConfirm = (parsed: ParsedEstimationItem[]) => {
    let acc = [...items];
    const newItems: EstimationItemDraft[] = [];
    for (const p of parsed) {
      const base = emptyItem(acc.length);
      const selling = p.selling_price_per_unit || (p.hpp_per_unit > 0 ? sellingFromHpp(p.hpp_per_unit, p.margin_pct) : 0);
      const displayName = uniquifyItemName(acc, p.name);
      const draft: EstimationItemDraft = {
        ...base,
        pricelist_item_id: p.pricelist_item_id || null,
        name: displayName,
        category: 'material',
        unit: p.unit,
        qty: p.qty,
        hpp_per_unit: p.hpp_per_unit > 0 && p.selling_price_per_unit ? p.hpp_per_unit : 0,
        margin_pct: p.margin_pct,
        selling_price_per_unit: selling,
      };
      const anchor: ItemPriceEdit = p.selling_price_per_unit ? 'selling' : p.hpp_per_unit > 0 ? 'margin' : 'selling';
      const row = { ...draft, ...calcItemRow(draft, anchor) };
      newItems.push(row);
      acc.push(row);
    }
    onChange([...items, ...newItems]);
  };

  const handlePricelistSelect = (picked: PricelistItem[]) => {
    let acc = [...items];
    for (const p of picked) {
      const row = pricelistToEstimationItem(p, acc.length);
      row.name = uniquifyItemName(acc, row.name);
      acc.push(row);
    }
    onChange(acc);
  };

  const fields: EditableField[] = ['name', 'qty', 'selling', 'margin', 'hpp'];

  const thClass = 'px-3 py-2.5 text-left text-[10px] font-bold text-slate-500 uppercase tracking-wide whitespace-nowrap';
  const tdClass = 'px-2 py-1.5 align-middle';
  const stickyCheck = 'sticky left-0 z-20 bg-white shadow-[2px_0_6px_-4px_rgba(15,23,42,0.12)]';
  const stickyNum = 'sticky left-10 z-20 bg-white shadow-[2px_0_6px_-4px_rgba(15,23,42,0.08)]';
  const stickyItem = 'sticky left-[4.75rem] z-20 bg-white min-w-[9.5rem] shadow-[2px_0_6px_-4px_rgba(15,23,42,0.06)]';
  const stickyHead = 'bg-slate-50';

  return (
    <>
      <div className="bg-white border border-[#E5EAE8] rounded-2xl shadow-sm overflow-hidden max-w-full">
        <div className="px-4 py-2.5 border-b border-[#E5EAE8] bg-white md:hidden space-y-2">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Rincian Produk</h3>
            {!readOnly && (
              <button
                type="button"
                onClick={openPricelistPicker}
                className="inline-flex items-center justify-center gap-1 min-h-11 px-3 rounded-full bg-emerald-600 text-white text-sm font-bold active:scale-95"
              >
                <Plus className="w-4 h-4" aria-hidden />
                Tambah
              </button>
            )}
          </div>
          {!readOnly && items.length > 0 && (
            <div>
              <button
                type="button"
                onClick={() => setEqualizeOpen(v => !v)}
                className="inline-flex items-center min-h-11 text-xs font-bold text-emerald-700"
              >
                Samakan ukuran semua item
              </button>
              {equalizeOpen && (
                <label className="mt-1 flex items-center gap-2 text-xs text-slate-500">
                  <span id="equalize-qty-label">Ukuran</span>
                  <GlobalQtyField
                    onApply={applyGlobalQty}
                    className="w-24 min-h-11 px-2 border border-[#E5EAE8] rounded-xl bg-white text-right"
                  />
                </label>
              )}
            </div>
          )}
        </div>

        {/* Desktop-only table header */}
        <div className="hidden md:flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 py-3 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3 flex-wrap min-w-0">
            <div>
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wide">Rincian Produk</h3>
              <p className="text-[11px] text-slate-600 mt-0.5">Harga jual & margin% menentukan HPP (margin = laba ÷ jual)</p>
            </div>
            {!readOnly && items.length > 0 && (
              <label className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="whitespace-nowrap font-semibold">Ukuran global</span>
                <GlobalQtyField
                  onApply={applyGlobalQty}
                  className="w-20 px-2 py-1.5 text-xs border border-slate-200 rounded-lg bg-white text-right"
                />
              </label>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {!readOnly && (
              <>
            {ENABLE_ESTIMATOR_SMART_INPUT && (
              <button
                type="button"
                onClick={() => setSmartOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-lg hover:opacity-90 shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Smart Input
              </button>
            )}
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-600 border border-emerald-200 rounded-lg hover:bg-emerald-50 bg-white"
              title="Dari Pricelist"
            >
              <List className="w-4 h-4" />
              Dari Pricelist
            </button>
            <button
              type="button"
              onClick={addRow}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 border border-slate-200 rounded-lg hover:bg-white bg-white"
              title="Tambah manual"
            >
              <Plus className="w-4 h-4" />
              Manual
            </button>
              </>
            )}
          </div>
        </div>

        {items.length === 0 ? (
          <div className="p-8 md:p-10 text-center space-y-4">
            <p className="text-sm font-semibold text-slate-700">Belum ada item</p>
            <p className="text-xs text-slate-500 md:hidden">Ketuk <strong>+ Tambah</strong> untuk pilih dari pricelist</p>
            {!readOnly && (
              <div className="hidden md:grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-2xl mx-auto">
              {ENABLE_ESTIMATOR_SMART_INPUT && (
                <button
                  type="button"
                  onClick={() => setSmartOpen(true)}
                  className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-50 text-left"
                >
                  <Sparkles className="w-5 h-5 text-emerald-600 mb-2" />
                  <div className="text-xs font-bold text-slate-800">Smart Input</div>
                  <div className="text-[10px] text-slate-500 mt-1">Ketik natural (paling cepat)</div>
                </button>
              )}
              <button
                type="button"
                onClick={() => setPickerOpen(true)}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50/30 text-left"
              >
                <List className="w-5 h-5 text-emerald-600 mb-2" />
                <div className="text-xs font-bold text-slate-800">Dari Pricelist</div>
                <div className="text-[10px] text-slate-500 mt-1">Pilih dari harga master</div>
              </button>
              <button
                type="button"
                onClick={addRow}
                className="p-4 rounded-xl border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50/30 text-left"
              >
                <Plus className="w-5 h-5 text-slate-600 mb-2" />
                <div className="text-xs font-bold text-slate-800">Manual</div>
                <div className="text-[10px] text-slate-500 mt-1">Isi baris satu-satu</div>
              </button>
            </div>
            )}
          </div>
        ) : (
          <>
        <div className="md:hidden p-2 space-y-2 overflow-x-hidden max-w-full">
          {items.map((item, idx) => {
            const netSelling = effectiveItemSelling(item);
            const rowMuted = item.name.trim() && item.included === false;
            const rowExpanded = expandedIndex === idx;
            const itemName = estimationItemDisplayName(item) || 'item';
            return (
              <div
                key={idx}
                className={`rounded-[14px] border overflow-hidden ${
                  rowMuted ? 'border-[#E5EAE8] bg-slate-50/80 opacity-80' : 'border-[#E5EAE8] bg-white'
                }`}
              >
                <div className="flex items-start gap-1 px-1 py-1">
                  <label className="inline-flex items-center justify-center min-h-12 min-w-12 shrink-0">
                    <input
                      type="checkbox"
                      checked={item.included !== false}
                      onChange={e => updateItem(idx, { included: e.target.checked }, 'qty')}
                      className="w-5 h-5 rounded border-slate-300 text-emerald-600"
                      aria-label={`Sertakan ${itemName} di penawaran`}
                    />
                  </label>
                  <div className="flex-1 min-w-0 py-2 pr-1">
                    <p className="font-semibold text-sm text-slate-900 leading-snug break-words">{itemName}</p>
                    <p className="mt-0.5 text-[11px] text-slate-500 break-words">
                      {item.qty} {item.unit} × {formatRupiahFull(item.selling_price_per_unit)}
                    </p>
                  </div>
                  <div className="pt-2 pr-0.5 text-right shrink-0">
                    <p className="text-sm font-bold text-slate-900 tabular-nums">{formatRupiahFull(netSelling)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => toggleRowExpanded(idx)}
                    className="inline-flex items-center justify-center min-h-11 min-w-11 text-slate-400 shrink-0"
                    aria-expanded={rowExpanded}
                    aria-label={rowExpanded ? 'Tutup detail item' : 'Buka detail item'}
                  >
                    <ChevronDown className={`w-5 h-5 transition-transform duration-200 ${rowExpanded ? 'rotate-180' : ''}`} />
                  </button>
                </div>

                <div
                  className={`grid transition-[grid-template-rows] duration-200 ${
                    rowExpanded ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'
                  }`}
                  inert={rowExpanded ? undefined : true}
                  aria-hidden={!rowExpanded}
                >
                  <div className="overflow-hidden">
                    <div className="px-3 pb-3 pt-1 border-t border-[#E5EAE8] space-y-3">
                      <label className="block text-[10px] font-bold uppercase tracking-wide text-slate-400">
                        Nama item
                        <input
                          value={item.name}
                          onChange={e => updateItem(idx, { name: e.target.value })}
                          placeholder="Nama item"
                          className="mt-1 w-full min-h-11 px-3 border border-[#E5EAE8] rounded-xl text-sm font-semibold text-slate-900 focus:border-emerald-400 outline-none"
                        />
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                          Ukuran
                          <QtyInput
                            value={item.qty}
                            onChange={v => updateItem(idx, { qty: v }, 'qty')}
                            className="mt-1 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm tabular-nums focus:border-emerald-400 outline-none"
                          />
                        </label>
                        <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                          Satuan
                          <select
                            value={item.unit}
                            onChange={e => updateItem(idx, { unit: e.target.value })}
                            className="mt-1 w-full min-h-11 px-1 border border-[#E5EAE8] rounded-xl bg-white text-sm"
                          >
                            {!COMMON_UNITS.includes(item.unit) && (
                              <option value={item.unit}>{item.unit}</option>
                            )}
                            {COMMON_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                          </select>
                        </label>
                        <label className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                          Harga per satuan (Rp)
                          <RupiahInput
                            value={item.selling_price_per_unit}
                            onChange={v => updateItem(idx, { selling_price_per_unit: v }, 'selling')}
                            className="mt-1 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm font-semibold tabular-nums focus:border-emerald-400 outline-none"
                          />
                        </label>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <label className="text-[10px] text-slate-500">
                          Margin %
                          <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.1"
                            value={item.margin_pct}
                            onMouseUp={e => e.preventDefault()}
                            onFocus={selectNumericField}
                            onChange={e => updateItem(idx, { margin_pct: Number(e.target.value) }, 'margin')}
                            className="mt-0.5 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm tabular-nums"
                          />
                        </label>
                        <label className="text-[10px] text-slate-500">
                          HPP / unit
                          <RupiahInput
                            value={item.hpp_per_unit}
                            onChange={v => updateItem(idx, { hpp_per_unit: v }, 'hpp')}
                            className="mt-0.5 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm tabular-nums"
                          />
                        </label>
                        <label className="text-[10px] text-slate-500 flex items-center gap-2 col-span-2 min-h-11">
                          <input
                            type="checkbox"
                            checked={item.is_bonus}
                            onChange={e => updateItem(idx, { is_bonus: e.target.checked }, 'qty')}
                            className="rounded border-slate-300 text-emerald-600"
                          />
                          Item bonus (gratis)
                        </label>
                        <label className="text-[10px] text-slate-500">
                          Disk. %
                          <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.1"
                            value={item.item_discount_pct || ''}
                            disabled={item.is_bonus}
                            onMouseUp={e => e.preventDefault()}
                            onFocus={selectNumericField}
                            onChange={e => updateItem(idx, { item_discount_pct: Number(e.target.value) }, 'qty')}
                            className="mt-0.5 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm disabled:bg-slate-50"
                            placeholder="0"
                          />
                        </label>
                        <label className="text-[10px] text-slate-500">
                          Disk. Rp
                          <RupiahInput
                            value={item.item_discount_amount}
                            onChange={v => updateItem(idx, { item_discount_amount: v }, 'qty')}
                            className="mt-0.5 w-full min-h-11 px-2 border border-[#E5EAE8] rounded-xl text-right text-sm"
                            min={0}
                          />
                        </label>
                        <label className="text-[10px] text-slate-500 col-span-2">
                          Kategori
                          <select
                            value={item.category}
                            onChange={e => updateItem(idx, { category: e.target.value })}
                            className="mt-0.5 w-full min-h-11 px-2 text-sm border border-[#E5EAE8] rounded-xl bg-white"
                          >
                            {PRICELIST_CATEGORIES.map(c => (
                              <option key={c.value} value={c.value}>{c.label}</option>
                            ))}
                          </select>
                        </label>
                      </div>

                      {!readOnly && (
                        <button
                          type="button"
                          onClick={() => removeRow(idx)}
                          className="inline-flex items-center justify-center gap-1.5 min-h-11 text-sm font-bold text-rose-600"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden />
                          Hapus item
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div className="hidden md:block overflow-x-auto overscroll-x-contain">
          <table className="w-full text-sm min-w-[1280px] table-auto">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className={`${thClass} ${stickyCheck} ${stickyHead} w-10 text-center`} title="Centang untuk masuk total estimasi">✓</th>
                  <th className={`${thClass} ${stickyNum} ${stickyHead} w-10`}>#</th>
                  <th className={`${thClass} ${stickyItem} ${stickyHead} min-w-[160px]`}>Item</th>
                  <th className={`${thClass} min-w-[80px] hidden lg:table-cell`}>Kat.</th>
                  <th className={`${thClass} min-w-[64px]`}>Sat.</th>
                  <th className={`${thClass} min-w-[64px] text-right`}>Qty</th>
                  <th className={`${thClass} min-w-[148px] text-right`}>Jual / unit</th>
                  <th className={`${thClass} min-w-[72px] text-right`}>Margin %</th>
                  <th className={`${thClass} min-w-[148px] text-right`}>HPP / unit</th>
                  <th className={`${thClass} min-w-[56px] text-center`}>Bonus</th>
                  <th className={`${thClass} min-w-[64px] text-right`}>Disk. %</th>
                  <th className={`${thClass} min-w-[120px] text-right`}>Disk. Rp</th>
                  <th className={`${thClass} min-w-[130px] text-right`}>Total HPP</th>
                  <th className={`${thClass} min-w-[130px] text-right`}>Total jual</th>
                  <th className="w-10" />
                </tr>
              </thead>
              <tbody>
                {items.map((item, idx) => {
                  const group = groupHeaderAt.get(idx);
                  const groupHeader =
                    group && shouldShowGroupHeader(group) ? (
                      <tr
                        key={`group-${group.key}-${idx}`}
                        className="bg-emerald-50/70 border-b border-emerald-100"
                      >
                        <td colSpan={3} className={`px-3 py-2 ${stickyCheck} bg-emerald-50/70`}>
                          <div className="text-xs font-bold text-emerald-800">{group.key}</div>
                        </td>
                        <td colSpan={2} className="px-2 py-2 bg-emerald-50/70" />
                        <td className={`${tdClass} text-right bg-emerald-50/70`}>
                          <QtyInput
                            value={groupSharedQty(group.indices, items) ?? 0}
                            onChange={v => setGroupQty(group.indices, v)}
                            placeholder="—"
                            className="w-full px-2 py-1.5 border border-emerald-300 bg-white rounded-lg text-right tabular-nums focus:border-emerald-500 outline-none font-semibold text-emerald-800"
                            title={`Qty global ${group.key} (${group.indices.length} item)`}
                          />
                        </td>
                        <td colSpan={9} className="px-3 py-2 text-[10px] text-emerald-600 align-middle bg-emerald-50/70">
                          {group.indices.length} item
                        </td>
                      </tr>
                    ) : null;

                  const productLabel = getEstimationItemProductGroup(item);
                  const netSelling = effectiveItemSelling(item);
                  const hasItemDiscount = netSelling !== item.total_selling || item.is_bonus;

                  const isCounted = item.included !== false;
                  const rowMuted = item.name.trim() && !isCounted;

                  return (
                    <Fragment key={idx}>
                      {groupHeader}
                      <tr
                        className={`border-b border-slate-100 transition-colors ${
                          rowMuted
                            ? 'bg-slate-50/90 opacity-60 hover:opacity-75'
                            : 'hover:bg-slate-50/60'
                        }`}
                      >
                        <td className={`${tdClass} text-center ${stickyCheck} ${rowMuted ? 'bg-slate-50/90' : 'bg-white'}`}>
                          <input
                            type="checkbox"
                            checked={isCounted}
                            onChange={e => updateItem(idx, { included: e.target.checked }, 'qty')}
                            className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                            title={isCounted ? 'Masuk total estimasi' : 'Tidak masuk total — item tetap disimpan'}
                          />
                        </td>
                        <td className={`${tdClass} text-slate-600 text-xs text-center ${stickyNum} ${rowMuted ? 'bg-slate-50/90' : 'bg-white'}`}>{idx + 1}</td>
                        <td className={`${tdClass} ${stickyItem} ${rowMuted ? 'bg-slate-50/90' : 'bg-white'}`}>
                          <div className="flex items-start gap-2 min-w-0">
                            <input
                              type="checkbox"
                              checked={isCounted}
                              onChange={e => updateItem(idx, { included: e.target.checked }, 'qty')}
                              className="w-4 h-4 mt-1 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 shrink-0 lg:hidden"
                              title={isCounted ? 'Masuk total' : 'Tidak masuk total'}
                            />
                            <div className="flex-1 min-w-0">
                              <input
                                ref={registerRef(`${idx}-name`)}
                                value={item.name}
                                onChange={e => updateItem(idx, { name: e.target.value })}
                                onKeyDown={e => handleKeyDown(e, idx, 'name', fields)}
                                className={`w-full px-2 py-1.5 border border-transparent hover:border-slate-200 rounded-lg focus:border-emerald-400 focus:ring-1 focus:ring-emerald-100 outline-none text-sm placeholder:text-slate-600 ${
                                  rowMuted ? 'text-slate-500 line-through decoration-slate-400' : 'text-slate-900'
                                }`}
                                placeholder="Nama item"
                                title={productLabel ? `Kelompok: ${productLabel}` : undefined}
                              />
                              {rowMuted && (
                                <span className="block text-[10px] text-slate-500 font-medium mt-0.5">Tidak masuk total</span>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className={`${tdClass} hidden lg:table-cell`}>
                          <select
                            value={item.category}
                            onChange={e => updateItem(idx, { category: e.target.value })}
                            className="w-full px-1.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-white text-slate-900"
                          >
                            {PRICELIST_CATEGORIES.map(c => (
                              <option key={c.value} value={c.value}>{c.label}</option>
                            ))}
                          </select>
                        </td>
                        <td className={tdClass}>
                          <select
                            value={item.unit}
                            onChange={e => updateItem(idx, { unit: e.target.value })}
                            className="w-full px-1.5 py-1.5 text-xs border border-slate-200 rounded-lg bg-white text-slate-900"
                          >
                            {COMMON_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                          </select>
                        </td>
                        <td className={tdClass}>
                          <QtyInput
                            inputRef={registerRef(`${idx}-qty`)}
                            value={item.qty}
                            onChange={v => updateItem(idx, { qty: v }, 'qty')}
                            onKeyDown={e => handleKeyDown(e, idx, 'qty', fields)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-right tabular-nums focus:border-emerald-400 outline-none"
                          />
                        </td>
                        <td className={`${tdClass} whitespace-nowrap`}>
                          <RupiahInput
                            inputRef={registerRef(`${idx}-selling`)}
                            value={item.selling_price_per_unit}
                            onChange={v => updateItem(idx, { selling_price_per_unit: v }, 'selling')}
                            onKeyDown={e => handleKeyDown(e, idx, 'selling', fields)}
                            title={`Harga jual per unit: ${formatRupiahFull(item.selling_price_per_unit)}`}
                            className="px-2 py-1.5 border border-emerald-200 bg-emerald-50/50 rounded-lg text-right font-semibold tabular-nums focus:border-emerald-400 focus:ring-1 focus:ring-emerald-100 outline-none"
                          />
                        </td>
                        <td className={tdClass}>
                          <input
                            ref={registerRef(`${idx}-margin`)}
                            type="number"
                            min={0}
                            max={100}
                            step="0.1"
                            value={item.margin_pct}
                            onMouseUp={e => e.preventDefault()}
                            onFocus={selectNumericField}
                            onChange={e => updateItem(idx, { margin_pct: Number(e.target.value) }, 'margin')}
                            onBlur={() => updateItem(idx, { margin_pct: item.margin_pct }, 'margin')}
                            onKeyDown={e => handleKeyDown(e, idx, 'margin', fields)}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-right tabular-nums focus:border-emerald-400 outline-none text-slate-900"
                            title="Margin = laba ÷ harga jual (100% = HPP nol)"
                          />
                        </td>
                        <td className={`${tdClass} whitespace-nowrap`}>
                          <RupiahInput
                            inputRef={registerRef(`${idx}-hpp`)}
                            value={item.hpp_per_unit}
                            onChange={v => updateItem(idx, { hpp_per_unit: v }, 'hpp')}
                            onKeyDown={e => handleKeyDown(e, idx, 'hpp', fields)}
                            title={`HPP per unit: ${formatRupiahFull(item.hpp_per_unit)}`}
                            className="px-2 py-1.5 border border-slate-200 bg-slate-50 rounded-lg text-right text-slate-700 tabular-nums focus:border-emerald-400 outline-none"
                          />
                        </td>
                        <td className={`${tdClass} text-center`}>
                          <input
                            type="checkbox"
                            checked={item.is_bonus}
                            onChange={e => updateItem(idx, { is_bonus: e.target.checked }, 'qty')}
                            className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                            title="Item bonus — tidak dihitung ke total jual"
                          />
                        </td>
                        <td className={tdClass}>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.1"
                            value={item.item_discount_pct || ''}
                            onMouseUp={e => e.preventDefault()}
                            onFocus={selectNumericField}
                            onChange={e => updateItem(idx, { item_discount_pct: Number(e.target.value) }, 'qty')}
                            disabled={item.is_bonus}
                            className="w-full px-2 py-1.5 border border-slate-200 rounded-lg text-right tabular-nums focus:border-emerald-400 outline-none text-slate-900 disabled:bg-slate-50 disabled:text-slate-400"
                            placeholder="0"
                          />
                        </td>
                        <td className={tdClass}>
                          <div className={item.is_bonus ? 'opacity-40 pointer-events-none' : ''}>
                            <RupiahInput
                              value={item.item_discount_amount}
                              onChange={v => updateItem(idx, { item_discount_amount: v }, 'qty')}
                              className="px-2 py-1.5 border border-slate-200 rounded-lg text-right text-sm min-w-[6rem]"
                              min={0}
                            />
                          </div>
                        </td>
                        <td className={`${tdClass} text-right text-sm text-slate-600 tabular-nums whitespace-nowrap`}>
                          {formatRupiahFull(item.total_hpp)}
                        </td>
                        <td className={`${tdClass} text-right font-bold text-slate-800 tabular-nums whitespace-nowrap`}>
                          {item.is_bonus && (
                            <span className="block text-[10px] font-bold text-amber-600 uppercase">Bonus</span>
                          )}
                          {hasItemDiscount && !item.is_bonus && item.total_selling > 0 && (
                            <span className="block text-[10px] text-slate-400 line-through font-normal">
                              {formatRupiahFull(item.total_selling)}
                            </span>
                          )}
                          {formatRupiahFull(netSelling)}
                        </td>
                        <td className={tdClass}>
                          {!readOnly && (
                          <button
                            type="button"
                            onClick={() => removeRow(idx)}
                            className="p-1.5 text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            aria-label="Hapus baris"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          )}
                        </td>
                      </tr>
                    </Fragment>
                  );
                })}
              </tbody>
              {countedItems.length > 0 && (
                <tfoot>
                  <tr className="bg-slate-50 border-t-2 border-slate-200 font-semibold text-xs">
                    <td colSpan={12} className="px-3 py-3 text-right text-slate-500 uppercase tracking-wide">
                      Total ({countedItems.length}
                      {namedItems.length > countedItems.length
                        ? ` dari ${namedItems.length} item`
                        : ' item'}
                      )
                    </td>
                    <td className="px-2 py-3 text-right text-slate-600 tabular-nums">
                      {formatRupiahFull(totals.subtotalHpp)}
                    </td>
                    <td className="px-2 py-3 text-right text-emerald-700 tabular-nums">
                      {formatRupiahFull(totals.subtotalSellingItems)}
                    </td>
                    <td />
                  </tr>
                  {(totals.billingDiscountAmount > 0 || totals.billingBonusNote) && (
                    <tr className="bg-white text-xs">
                      <td colSpan={12} className="px-3 py-2 text-right text-slate-500">
                        {totals.billingDiscountAmount > 0 ? 'Potongan tagihan' : 'Bonus'}
                        {totals.billingBonusNote ? ` · ${totals.billingBonusNote}` : ''}
                      </td>
                      <td />
                      <td className="px-2 py-2 text-right text-rose-600 tabular-nums">
                        {totals.billingDiscountAmount > 0 ? `−${formatRupiahFull(totals.billingDiscountAmount)}` : '—'}
                      </td>
                      <td />
                    </tr>
                  )}
                  {(totals.billingDiscountAmount > 0 || totals.billingBonusNote) && (
                    <tr className="bg-emerald-50 text-xs font-bold">
                      <td colSpan={12} className="px-3 py-2 text-right text-emerald-800 uppercase tracking-wide">
                        Total akhir
                      </td>
                      <td />
                      <td className="px-2 py-2 text-right text-emerald-800 tabular-nums">
                        {formatRupiahFull(totals.grandTotal)}
                      </td>
                      <td />
                    </tr>
                  )}
                </tfoot>
              )}
            </table>
          </div>
          </>
        )}
      </div>

      {smartOpen && (
        <SmartInputModal
          orgId={orgId}
          defaultMargin={defaultMargin}
          onClose={() => setSmartOpen(false)}
          onConfirm={handleSmartConfirm}
        />
      )}
      {pickerOpen && (
        <PricelistPickerModal
          orgId={orgId}
          userId={userId}
          onClose={() => setPickerOpen(false)}
          onSelect={handlePricelistSelect}
          onToast={(msg, type) => showToast(msg, type)}
        />
      )}
    </>
  );
}
