import { resolveSupabaseEnv } from './env';

const { url: supabaseUrl, anonKey: supabaseAnonKey } = resolveSupabaseEnv();

export const config = {
  supabaseUrl,
  supabaseAnonKey,
  fnParseCommand: 'planner-parse-command',
  fnAnalyze: 'planner-analyze',
  fnCreateOwnerOrg: 'planner-create-owner-org',
  fnValidateInvitation: 'planner-validate-invitation',
  fnCreateInvitation: 'planner-create-invitation',
  fnAcceptInvitation: 'planner-accept-invitation',
  fnSendInvitationEmail: 'planner-send-invitation-email',
  fnRevokeInvitation: 'planner-revoke-invitation',
  fnDirectCreateMember: 'planner-direct-create-member',
  fnSubmitJoinRequest: 'planner-submit-join-request',
  fnApproveJoinRequest: 'planner-approve-join-request',
  fnRejectJoinRequest: 'planner-reject-join-request',
  fnChangeMemberRole: 'planner-change-member-role',
  fnRemoveMember: 'planner-remove-member',
  fnTransferOwnership: 'planner-transfer-ownership',
  fnSearchCompanies: 'planner-search-companies',
  fnTryDomainJoin: 'planner-try-domain-join',
  fnAdminUsers: 'monefyi-admin-users',
  fnAdminUpdateUser: 'monefyi-admin-update-user',
  fnAdminAppConfig: 'monefyi-admin-app-config',
  fnAdminPlatformStats: 'monefyi-admin-platform-stats',
  fnAdminCompanyTypes: 'monefyi-admin-company-types',
  fnUserAccount: 'monefyi-user-account',
  fnPlannerCheckout: 'planner-checkout',
  appEnv:
    (import.meta.env.VITE_APP_ENV as string) ||
    (import.meta.env.VERCEL_ENV as string) ||
    (import.meta.env.MODE as string) ||
    'development',
  devDemoAuth: import.meta.env.VITE_DEV_DEMO_AUTH === 'true',
  skipEmailVerify: import.meta.env.VITE_SKIP_EMAIL_VERIFY === 'true',
  posthogKey:
    (import.meta.env.VITE_POSTHOG_KEY as string) ||
    (import.meta.env.NEXT_PUBLIC_POSTHOG_KEY as string) ||
    '',
  posthogHost:
    (import.meta.env.VITE_POSTHOG_HOST as string) ||
    (import.meta.env.NEXT_PUBLIC_POSTHOG_HOST as string) ||
    'https://app.posthog.com',
};

export function assertSupabaseConfig(): void {
  if (!config.supabaseUrl || !config.supabaseAnonKey) {
    throw new Error(
      'Supabase belum dikonfigurasi. Set salah satu pasangan env: ' +
        'VITE_SUPABASE_URL + VITE_SUPABASE_ANON_KEY (lokal), atau ' +
        'NEXT_PUBLIC_SUPABASE_URL + NEXT_PUBLIC_SUPABASE_ANON_KEY / SUPABASE_URL + SUPABASE_ANON_KEY (Vercel + Supabase integration).',
    );
  }
}

export { resolveSupabaseEnv };
