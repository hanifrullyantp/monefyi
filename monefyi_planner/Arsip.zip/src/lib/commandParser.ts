import { firstRupiah, parseCostCommand } from '../../../packages/domain/src/money';
import { storedAmountConflicts } from '../../../packages/domain/src/validation';
import { finalizeParams } from './commandNormalize';

export type ParseSource = 'memory' | 'rule' | 'ai' | 'fuzzy' | 'fallback';

export interface ParsedCommand {
  intent: string;
  params: Record<string, unknown>;
  confidence: number;
  raw: string;
  source?: ParseSource;
  memoryId?: string;
  memoryHitCount?: number;
  provider?: string;
  reasoning?: string;
  layer?: number;
}

function getParsingRules() {
  return [
    {
      intent: 'record_cost',
      patterns: [
        /(?:beli|bayar|byr|bl|catat\s+beli|catat)\s+(.+?)\s+(\d+[\d.,]*)\s*(?:sak|kg|m3|m³|kubik|btg|batang|buah|unit|ls|lot|pcs|lembar|lbr|roll|meter|mtr)\s*(?:@|harga|hrg|x|×)?\s*(?:rp\.?\s*)?(\d[\d.,]*)\s*(?:ribu|rb|k)?/i,
        /(?:beli|bayar|byr|bl|catat\s+beli|catat)\s+(.+?)\s+(?:rp\.?\s*)?(\d[\d.,]*)\s*(?:ribu|rb|k|juta|jt)?/i,
        /(?:beli|bayar|byr|catat)\s+(.+?)\s+(\d[\d.,]*)\s*(?:sak|kg|m3|kubik|btg|buah|unit|ls|pcs)\s+(?:rp\.?\s*)?(\d[\d.,]*)/i,
      ],
      confidence: 0.85,
      extract: (_match: RegExpMatchArray, input: string) => {
        const parsed = parseCostCommand(input);
        if (!parsed) return { item: '', total: 0, needsReview: true };
        return parsed;
      },
    },
    {
      intent: 'record_income',
      patterns: [
        /(?:terima|terim|dp|termin|pelunasan|catat\s+(?:uang\s+)?masuk|pemasukan)\s+(?:rp\.?\s*)?(\d[\d.,]*)\s*(?:ribu|rb|k|juta|jt)?(?:\s+(?:dp|termin|pelunasan|retensi))?\s*(?:project|proyek|prj)?\s*(.*)?/i,
        /(?:terima|catat)\s+(dp|termin|pelunasan|retensi)\s+(?:rp\.?\s*)?(\d[\d.,]*)\s*(?:ribu|rb|k|juta|jt)?\s*(?:project|proyek|prj)?\s*(.*)?/i,
      ],
      confidence: 0.82,
      extract: (match: RegExpMatchArray, input: string) => {
        let category = 'other';
        let projectName = match[2]?.trim() || null;
        if (['dp', 'termin', 'pelunasan', 'retensi'].includes(String(match[1]).toLowerCase())) {
          category = String(match[1]).toLowerCase();
          projectName = match[3]?.trim() || null;
        } else {
          const catMatch = input.match(/\b(dp|termin|pelunasan|retensi)\b/i);
          if (catMatch) category = catMatch[1].toLowerCase();
        }
        const money = firstRupiah(input);
        const total = money.ok ? money.amount : 0;
        return {
          total,
          amount: total,
          category,
          projectName,
          item: `Penerimaan ${category}`,
          description: `Penerimaan ${category}`,
          needsReview: !money.ok || money.needsReview,
        };
      },
    },
    {
      intent: 'update_progress',
      patterns: [
        /(?:progress|proses|hari\s+ini)\s+(.+?)\s+(?:selesai\s+)?(\d+)\s*(?:%|persen|prosen)/i,
        /(.+?)\s+(?:sudah|sdh|udah|udh)\s+(\d+)\s*(?:%|persen|prosen)/i,
        /(?:update|upd)\s+(?:progress|proses)\s+(.+?)\s+(\d+)\s*(?:%|persen)?/i,
      ],
      confidence: 0.85,
      extract: (match: RegExpMatchArray) => ({
        workItem: match[1]?.trim(),
        progress: parseInt(match[2]) || 0,
      }),
    },
    {
      intent: 'check_budget',
      patterns: [
        /(?:cek|check|berapa|lihat)\s+(?:budget|anggaran|biaya|sisa|rap)\s*(?:project|proyek|prj)?\s*(.*)?/i,
        /(?:sisa\s+(?:budget|anggaran))\s*(.*)?/i,
      ],
      confidence: 0.9,
      extract: (match: RegExpMatchArray) => ({ projectName: match[1]?.trim() || null }),
    },
    {
      intent: 'check_progress',
      patterns: [
        /(?:cek|check|berapa|lihat)\s+(?:progress|proses)\s*(?:project|proyek|prj)?\s*(.*)?/i,
        /(?:progress)\s+(?:project|proyek|prj)\s+(.*)/i,
      ],
      confidence: 0.9,
      extract: (match: RegExpMatchArray) => ({ projectName: match[1]?.trim() || null }),
    },
    {
      intent: 'open_project',
      patterns: [/(?:buka|open|tampilkan|lihat)\s+(?:project|proyek|prj)\s+(.*)/i],
      confidence: 0.9,
      extract: (match: RegExpMatchArray) => ({ projectName: match[1]?.trim() }),
    },
    {
      intent: 'add_worker_log',
      patterns: [
        /(?:hari\s+ini|log)\s+(?:hadir|kerja|pekerja)\s+(\d+)\s*(?:orang|org)/i,
        /(?:pekerja|tukang|kuli)\s+(?:hadir|datang)\s+(\d+)\s*(?:orang|org)?/i,
      ],
      confidence: 0.8,
      extract: (match: RegExpMatchArray) => ({ workers: parseInt(match[1]) || 0 }),
    },
    {
      intent: 'open_report',
      patterns: [/(?:buka|lihat|tampilkan|show)\s+(?:laporan|report)/i],
      confidence: 0.9,
      extract: () => ({}),
    },
    {
      intent: 'ask_recommendation',
      patterns: [/(?:rekomendasi|saran|analisa|analisis)\s*(?:project|proyek|prj|untuk)?\s*(.*)?/i],
      confidence: 0.85,
      extract: (match: RegExpMatchArray) => ({ projectName: match[1]?.trim() || null }),
    },
  ];
}

export function parseCommand(input: string): ParsedCommand {
  const cost = parseCostCommand(input);
  if (cost?.item) {
    return {
      intent: 'record_cost',
      params: { ...cost },
      confidence: cost.needsReview ? 0.62 : 0.85,
      raw: input,
      source: 'rule',
    };
  }

  const lower = input.toLowerCase().trim();
  const rules = getParsingRules();

  for (const rule of rules) {
    for (const pattern of rule.patterns) {
      const match = lower.match(pattern) || input.match(pattern);
      if (match) {
        const params = rule.extract(match, input);
        const needsReview = Boolean((params as { needsReview?: boolean }).needsReview);
        return {
          intent: rule.intent,
          params,
          confidence: needsReview ? Math.min(rule.confidence, 0.62) : rule.confidence,
          raw: input,
          source: 'rule',
        };
      }
    }
  }

  return { intent: 'unknown', params: {}, confidence: 0, raw: input, source: 'rule' };
}

export interface PipelineContext {
  orgId?: string;
  projects: Array<{ name: string; id: string; status?: string }>;
  work_items: Array<{ name: string; id: string; progress?: number }>;
  current_project: string | null;
  /** Dari perintah sebelumnya: "buat estimasi" / "buat project". */
  leadTargetHint?: 'estimation' | 'project';
}

export function createAIFallbackParse(
  input: string,
  message?: string,
): ParsedCommand {
  return {
    intent: 'record_cost',
    params: {},
    confidence: 0.35,
    raw: input,
    source: 'fallback',
    reasoning: message || 'AI tidak tersedia — silakan isi form manual di bawah.',
  };
}

export async function aiParseCommand(
  input: string,
  context: PipelineContext,
): Promise<ParsedCommand> {
  try {
    const { config } = await import('./config');
    const { supabase } = await import('./supabase');

    let learned_examples: Array<{ input: string; intent: string; params: unknown }> = [];
    if (context.orgId) {
      try {
        const { loadMemoryExamples } = await import('../services/commandMemoryService');
        learned_examples = await loadMemoryExamples(context.orgId);
      } catch {
        learned_examples = [];
      }
    }

    const { data } = await supabase.functions.invoke(config.fnParseCommand, {
      body: { input, context: { ...context, learned_examples } },
    });

    if (data?.intent && data.intent !== 'unknown') {
      return {
        intent: data.intent,
        params: data.params || {},
        confidence: Number(data.confidence) || 0.7,
        raw: input,
        source: 'ai',
        provider: data?._meta?.provider,
        reasoning: data.explanation || data.message || undefined,
      };
    }

    if (data?.intent === 'unknown' && data?.explanation) {
      return {
        intent: 'record_cost',
        params: data.params || {},
        confidence: 0.4,
        raw: input,
        source: 'ai',
        reasoning: data.explanation || data.message,
      };
    }
  } catch (e) {
    console.warn('AI parser fallback failed:', e);
  }
  return createAIFallbackParse(input);
}

/**
 * Full parsing pipeline: org learning memory -> regex rules -> AI fallback.
 * Returns the best ParsedCommand, tagged with its `source`.
 * `onStage` reports progress for UI ('memory' | 'rule' | 'ai').
 */
export async function runCommandPipeline(
  input: string,
  context: PipelineContext,
  onStage?: (stage: ParseSource) => void,
): Promise<ParsedCommand> {
  // 1. Learning memory (deterministic, free, org-shared).
  if (context.orgId) {
    onStage?.('memory');
    try {
      const { lookupMemory } = await import('../services/commandMemoryService');
      const match = await lookupMemory(context.orgId, input);
      const remembered = match ? finalizeParams(match.params) : null;
      if (match && remembered && !storedAmountConflicts(input, remembered)) {
        return {
          intent: match.intent,
          params: remembered,
          confidence: 0.95,
          raw: input,
          source: 'memory',
          memoryId: match.memoryId,
        };
      }
    } catch (e) {
      console.warn('Memory lookup failed:', e);
    }
  }

  // 2. WhatsApp multi-line batch costs.
  onStage?.('rule');
  if (input.includes('\n')) {
    const { parseCostText } = await import('./costParser');
    const items = parseCostText(input);
    if (items.length > 0) {
      return {
        intent: 'record_cost_batch',
        params: { items },
        confidence: 0.9,
        raw: input,
        source: 'rule',
      };
    }
  }

  const ruleResult = parseCommand(input);
  if (ruleResult.intent !== 'unknown' && ruleResult.confidence >= 0.75) {
    return ruleResult;
  }

  // 3. AI fallback (+ few-shot from org memory).
  onStage?.('ai');
  const aiResult = await aiParseCommand(input, context);
  if (aiResult.confidence >= 0.6 && aiResult.intent !== 'unknown') {
    return aiResult;
  }

  if (ruleResult.intent !== 'unknown') {
    return { ...ruleResult, confidence: Math.max(ruleResult.confidence, 0.45) };
  }

  return aiResult;
}
