/** Brand assets — Monefyi Estimator (mark E hijau). */
import { resolveSpaAssetUrl } from './spaAssets';
import { applyPlannerDocumentBrand } from './plannerBrand';

const V = '2026-10-28';

/** Mark E — SVG prioritas; PNG fallback di komponen jika perlu */
export const ESTIMATOR_LOGO_SRC = `/icons/estimator/mark.svg?v=${V}`;
export const ESTIMATOR_LOGO_PNG_SRC = `/icons/estimator/estimator-logo.png?v=${V}`;
export const ESTIMATOR_FAVICON_SRC = `/icons/estimator/favicon.png?v=${V}`;
export const ESTIMATOR_APPLE_ICON_SRC = `/icons/estimator/icon-180.png?v=${V}`;
export const ESTIMATOR_ICON_192_SRC = `/icons/estimator/icon-192.png?v=${V}`;

export const ESTIMATOR_BRAND_NAME = 'Monefyi Estimator';
/** CTA / theme — brand-600 (AA on white) */
export const ESTIMATOR_THEME_COLOR = '#157F5F';

/** Host / PWA Estimator — bukan rute SPA (Planner user tetap Planner di /app/estimator). */
export function isEstimatorBrandContext(): boolean {
  if (typeof window === 'undefined') return false;
  const { hostname } = window.location;
  return hostname === 'estimator.monefyi.com' || hostname.startsWith('estimator.');
}

export function applyEstimatorDocumentBrand(active: boolean): void {
  if (typeof document === 'undefined') return;

  const icon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
  const apple = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
  const theme = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');

  if (active) {
    if (icon) icon.href = resolveSpaAssetUrl(ESTIMATOR_FAVICON_SRC);
    if (apple) apple.href = resolveSpaAssetUrl(ESTIMATOR_APPLE_ICON_SRC);
    if (theme) theme.content = ESTIMATOR_THEME_COLOR;
    if (!document.title.includes('Estimator')) {
      document.title = `Estimator — ${document.title}`;
    }
    return;
  }

  applyPlannerDocumentBrand();
}
