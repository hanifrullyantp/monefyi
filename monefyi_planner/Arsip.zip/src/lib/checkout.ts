import {
  ESTIMATOR_PRICE_IDR,
  ESTIMATOR_PRO_PRICE_IDR,
  PRO_PRICE_MONTHLY_IDR,
} from './entitlement';
import { resolveEstimatorStandardCheckoutAmount } from './estimatorLaunchPromo';
import { loadEstimatorLaunchPromoStatus } from '../services/launchPromoService';
import { config } from './config';
import { resolvePaymentProvider } from './paymentProvider';
import { supabase } from './supabase';

export type CheckoutProduct = 'estimator_standard' | 'estimator_pro' | 'planner_pro' | 'estimator' | 'pro' | 'enterprise';

export interface CheckoutRedirectOptions {
  orgId: string;
  userId: string;
  creditAmount?: number;
  returnUrl?: string;
  email?: string;
  /** Override jumlah tagihan Lynk (upgrade selisih, dll.). */
  checkoutAmount?: number;
  /** Tandai upgrade dari paket sebelumnya — dikirim ke webhook Lynk. */
  upgradeFrom?: 'estimator_standard';
}

const ENV_KEYS: Record<'estimator_standard' | 'estimator_pro' | 'planner_pro', string> = {
  estimator_standard: 'VITE_LYNK_ESTIMATOR_STANDARD',
  estimator_pro: 'VITE_LYNK_ESTIMATOR_PRO',
  planner_pro: 'VITE_LYNK_PLANNER_PRO',
};

function readEnv(key: string): string {
  const env = import.meta.env as Record<string, string | undefined>;
  return (
    env[key]?.trim() ||
    env[key.replace('VITE_', 'NEXT_PUBLIC_')]?.trim() ||
    ''
  );
}

export function resolveLynkBaseUrl(product: 'estimator_standard' | 'estimator_pro' | 'planner_pro'): string {
  return readEnv(ENV_KEYS[product]);
}

/** Map legacy product ids to Lynk product keys. */
export function normalizeCheckoutProduct(product: CheckoutProduct): 'estimator_standard' | 'estimator_pro' | 'planner_pro' {
  if (product === 'estimator' || product === 'estimator_standard') return 'estimator_standard';
  if (product === 'pro' || product === 'planner_pro') return 'planner_pro';
  if (product === 'estimator_pro') return 'estimator_pro';
  return 'estimator_standard';
}

export function buildCheckoutUrl(
  product: CheckoutProduct,
  options: CheckoutRedirectOptions,
): string {
  const lynkProduct = normalizeCheckoutProduct(product);
  const base = resolveLynkBaseUrl(lynkProduct);
  if (!base) {
    throw new Error(`Checkout Lynk belum dikonfigurasi (${ENV_KEYS[lynkProduct]}).`);
  }

  const returnUrl = options.returnUrl
    ?? (typeof window !== 'undefined' ? window.location.href : 'https://estimator.monefyi.com/app/estimator');

  const url = new URL(base);
  url.searchParams.set('org_id', options.orgId);
  url.searchParams.set('user_id', options.userId);
  url.searchParams.set('product', lynkProduct);
  if (options.email) url.searchParams.set('customer_email', options.email);
  url.searchParams.set('return_url', returnUrl);

  const amount = options.checkoutAmount;
  if (lynkProduct === 'estimator_standard') {
    url.searchParams.set('amount', String(amount ?? ESTIMATOR_PRICE_IDR));
  }
  if (lynkProduct === 'estimator_pro') {
    url.searchParams.set('amount', String(amount ?? ESTIMATOR_PRO_PRICE_IDR));
    if (options.upgradeFrom === 'estimator_standard') {
      url.searchParams.set('upgrade_from', 'estimator_standard');
    }
  }
  if (lynkProduct === 'planner_pro') {
    url.searchParams.set('amount', String(PRO_PRICE_MONTHLY_IDR));
    if (options.creditAmount && options.creditAmount > 0) {
      url.searchParams.set('credit', String(options.creditAmount));
    }
  }

  return url.toString();
}

export function redirectToCheckout(
  product: CheckoutProduct,
  options: CheckoutRedirectOptions,
): void {
  void redirectToCheckoutAsync(product, options);
}

async function resolveCheckoutOptions(
  product: CheckoutProduct,
  options: CheckoutRedirectOptions,
): Promise<CheckoutRedirectOptions> {
  const lynkProduct = normalizeCheckoutProduct(product);
  const opts = { ...options };
  if (lynkProduct === 'estimator_standard' && opts.checkoutAmount == null) {
    try {
      const promo = await loadEstimatorLaunchPromoStatus();
      opts.checkoutAmount = resolveEstimatorStandardCheckoutAmount(promo);
    } catch {
      opts.checkoutAmount = ESTIMATOR_PRICE_IDR;
    }
  }
  return opts;
}

async function redirectViaMayarCheckout(
  product: CheckoutProduct,
  options: CheckoutRedirectOptions,
): Promise<void> {
  const lynkProduct = normalizeCheckoutProduct(product);
  const { data, error } = await supabase.functions.invoke(config.fnPlannerCheckout, {
    body: {
      provider: 'mayar',
      product: lynkProduct,
      orgId: options.orgId,
      userId: options.userId,
      email: options.email,
      returnUrl: options.returnUrl,
      checkoutAmount: options.checkoutAmount,
      upgradeFrom: options.upgradeFrom,
      creditAmount: options.creditAmount,
    },
  });

  if (error) {
    throw new Error(error.message || 'Checkout Mayar gagal');
  }
  const redirectUrl = String((data as { redirectUrl?: string })?.redirectUrl ?? '').trim();
  if (!redirectUrl) {
    throw new Error(String((data as { error?: string })?.error ?? 'URL checkout Mayar kosong'));
  }
  window.location.href = redirectUrl;
}

/** Resolves launch promo price, then redirects to Lynk or Mayar. */
export async function redirectToCheckoutAsync(
  product: CheckoutProduct,
  options: CheckoutRedirectOptions,
): Promise<void> {
  const opts = await resolveCheckoutOptions(product, options);
  if (resolvePaymentProvider() === 'mayar') {
    await redirectViaMayarCheckout(product, opts);
    return;
  }
  window.location.href = buildCheckoutUrl(product, opts);
}

export function cleanPaymentQueryFromUrl(): void {
  if (typeof window === 'undefined') return;
  const url = new URL(window.location.href);
  url.searchParams.delete('payment');
  url.searchParams.delete('order_id');
  const next = `${url.pathname}${url.search}${url.hash}`;
  window.history.replaceState({}, '', next);
}

export function readPaymentReturnStatus(): 'success' | 'failed' | 'cancelled' | null {
  if (typeof window === 'undefined') return null;
  const payment = new URLSearchParams(window.location.search).get('payment');
  if (payment === 'success' || payment === 'failed' || payment === 'cancelled') {
    return payment;
  }
  return null;
}
