import { describe, expect, it } from 'vitest';
import { mapPlannerProject } from './planner-mapper';

describe('planner-mapper', () => {
  it('maps qtyActual from cost realizations per RAP line', () => {
    const projectId = 'test-project-id';
    const rapId = 'rap-holo-id';

    const mapped = mapPlannerProject({
      project: {
        id: projectId,
        org_id: 'org-1',
        name: 'Kitchen Set Kota Baru',
        client_name: 'Klien',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        status: 'active',
        progress_pct: 10,
        total_budget: 29_691_500,
        total_spent: 810_000,
        total_received: 9_700_000,
        settings: { type: 'Interior' },
      },
      rapItems: [
        {
          id: rapId,
          project_id: projectId,
          type: 'material',
          name: 'Holo galvanis 1530 0,8 Sinar Raya',
          unit: 'btg',
          quantity: 15,
          unit_price: 54_000,
          supplier: 'Sinar Raya',
        },
      ],
      costs: [
        {
          id: 'cost-1',
          project_id: projectId,
          rap_item_id: rapId,
          date: '2026-03-01',
          description: 'Realisasi: Holo galvanis',
          quantity: 15,
          unit_price: 54_000,
          total_amount: 810_000,
        },
      ],
      incomes: [],
      workItems: [],
    });

    const holo = mapped.rap.materials[0];
    expect(holo.qtyActual).toBe(15);
    expect(holo.total).toBe(810_000);
    expect(holo.qtyPlan).toBe(15);
  });

  it('hutang list uses vendor names not cost descriptions', () => {
    const mapped = mapPlannerProject({
      project: {
        id: 'p2',
        org_id: 'org-1',
        name: 'Kitchen set Cece',
        client_name: 'INTERO',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        total_budget: 29_700_000,
        total_spent: 27_200_000,
        total_received: 20_000_000,
      },
      rapItems: [],
      costs: [
        { id: 'c1', project_id: 'p2', date: '2026-02-01', description: 'Import', total_amount: 5_000_000, supplier: null },
        { id: 'c2', project_id: 'p2', date: '2026-02-02', description: 'fischer 10 mm', total_amount: 1_000_000, supplier: null },
        { id: 'c3', project_id: 'p2', date: '2026-02-03', description: 'Holo galvanis', total_amount: 2_000_000, supplier: 'Sinar Raya' },
      ],
      incomes: [{ id: 'i1', project_id: 'p2', date: '2026-02-01', amount: 20_000_000, category: 'DP', description: 'DP pertama', status: 'received' }],
      workItems: [],
    });

    expect(mapped.saldo).toBe(-7_200_000);
    const hutang = mapped.hutangPiutang.filter(h => h.type === 'hutang');
    expect(hutang.some(h => h.name.includes('Import'))).toBe(false);
    expect(hutang.some(h => h.name.includes('fischer'))).toBe(false);
    expect(hutang.some(h => h.partyName === 'Sinar Raya')).toBe(true);
    const piutang = mapped.hutangPiutang.find(h => h.type === 'piutang');
    expect(piutang?.partyName).toBe('INTERO');
  });

  it('contractValue prefers settings.contract_value over total_budget', () => {
    const mapped = mapPlannerProject({
      project: {
        id: 'p3',
        org_id: 'org-1',
        name: 'Kitchen set Cece',
        client_name: 'INTERO',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        total_budget: 29_691_500,
        total_spent: 27_200_000,
        total_received: 20_000_000,
        settings: { contract_value: 53_000_000, type: 'furniture' },
      },
      rapItems: [],
      costs: [],
      incomes: [],
      workItems: [],
    });

    expect(mapped.contractValue).toBe(53_000_000);
    expect(mapped.budget.piutang).toBe(33_000_000);
  });

  it('uses planner_payables and planner_receivables when provided', () => {
    const mapped = mapPlannerProject({
      project: {
        id: 'p4',
        org_id: 'org-1',
        name: 'Kitchen set Cece',
        client_name: 'INTERO',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        total_budget: 53_000_000,
        total_spent: 27_200_000,
        total_received: 20_000_000,
        settings: { contract_value: 53_000_000 },
      },
      rapItems: [],
      costs: [],
      incomes: [],
      workItems: [],
      payables: [
        {
          id: 'pay-1',
          creditor_name: 'PT Baja',
          amount: 5_000_000,
          paid_amount: 1_000_000,
          due_date: '2026-04-01',
          status: 'partial',
        },
      ],
      receivables: [
        {
          id: 'rec-1',
          debtor_name: 'Klien A',
          amount: 8_000_000,
          paid_amount: 0,
          due_date: '2026-05-01',
          status: 'open',
        },
      ],
    });

    expect(mapped.budget.hutang).toBe(4_000_000);
    expect(mapped.budget.piutang).toBe(8_000_000);
    expect(mapped.hutangPiutang.find(h => h.type === 'hutang')?.partyName).toBe('PT Baja');
    expect(mapped.hutangPiutang.find(h => h.type === 'piutang')?.partyName).toBe('Klien A');
  });

  it('empty ledger rows override derived hutang and piutang', () => {
    const mapped = mapPlannerProject({
      project: {
        id: 'p5',
        org_id: 'org-1',
        name: 'Proyek',
        client_name: 'Klien',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        total_budget: 50_000_000,
        total_spent: 30_000_000,
        total_received: 10_000_000,
      },
      rapItems: [],
      costs: [],
      incomes: [],
      workItems: [],
      payables: [],
      receivables: [],
    });

    expect(mapped.budget.hutang).toBe(0);
    expect(mapped.budget.piutang).toBe(0);
    expect(mapped.hutangPiutang).toEqual([]);
  });

  it('reduces cash when ledger piutang exceeds remaining contract', () => {
    const mapped = mapPlannerProject({
      project: {
        id: 'p6',
        org_id: 'org-1',
        name: 'KITCHEN SET FINA',
        client_name: 'Fina',
        planned_start: '2026-01-01',
        planned_end: '2026-06-01',
        total_budget: 30_200_000,
        total_spent: 17_000_000,
        total_received: 30_200_000,
        settings: { contract_value: 30_200_000 },
      },
      rapItems: [],
      costs: [],
      incomes: [],
      workItems: [],
      payables: [],
      receivables: [{
        id: 'rec-fina',
        debtor_name: 'Fina',
        amount: 1_787_000,
        paid_amount: 0,
        due_date: '2026-06-01',
        status: 'open',
      }],
    });

    expect(mapped.budget.piutang).toBe(1_787_000);
    expect(mapped.saldo).toBe(11_413_000);
  });
});
