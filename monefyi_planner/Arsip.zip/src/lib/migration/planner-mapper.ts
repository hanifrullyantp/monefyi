// Map planner_* rows → sandbox-compatible project view for balance sheet & V2 tabs.

import { schedulePlanProgress, weightedActualProgress } from '../progressMetrics';
import { extraPiutangBeyondContract } from '../projects/cashIdentity';

export type MappedRapItem = {
  id: number;
  plannerId?: string;
  name: string;
  unit: string;
  unitPrice: number;
  qtyPlan: number;
  qtyActual: number;
  total: number;
  rapTotal: number;
  status: string;
  checked: boolean;
  vendor: string;
};

export type MappedProjectView = {
  id: string | number;
  name: string;
  client: string;
  type: string;
  startDate: string;
  endDate: string;
  duration: number;
  contractValue: number;
  saldo: number;
  status: 'ok' | 'warning' | 'danger';
  progress: { plan: number; actual: number; deviation: number };
  rap: {
    totalRAP: number;
    realisasi: number;
    estLaba: number;
    materials: MappedRapItem[];
    workers: MappedRapItem[];
  };
  budget: {
    bahan: { plan: number; actual: number };
    tukang: { plan: number; actual: number };
    piutang: number;
    hutang: number;
  };
  payments: Array<{ id: number; type: 'in'; name: string; amount: number; date: string; time: string; icon: string }>;
  expenses: Array<{ id: number; type: 'out'; category: string; name: string; amount: number; date: string; time: string; icon: string }>;
  timeline: Array<{ id: number; name: string; weight: number; progress: number; planProgress: number; status: string; start: string; end: string }>;
  hutangPiutang: Array<{
    id: number;
    type: 'hutang' | 'piutang';
    name: string;
    /** Nama pihak lawan: vendor (hutang) atau klien (piutang) */
    partyName?: string;
    amount: number;
    due: string;
    status: string;
  }>;
};

export type PlannerProjectRow = {
  id: string;
  org_id: string;
  name: string;
  client_name?: string | null;
  planned_start: string;
  planned_end: string;
  status?: string | null;
  progress_pct?: string | number | null;
  total_budget?: string | number | null;
  total_spent?: string | number | null;
  total_received?: string | number | null;
  settings?: Record<string, unknown> | null;
};

export type PlannerRapRow = {
  id: string;
  project_id: string;
  type: string;
  name: string;
  unit: string;
  quantity: string | number;
  unit_price: string | number;
  supplier?: string | null;
  sort_order?: number | null;
};

export type PlannerCostRow = {
  id: string;
  project_id: string;
  rap_item_id?: string | null;
  date: string;
  description: string;
  quantity?: string | number | null;
  unit_price?: string | number | null;
  total_amount: string | number;
  supplier?: string | null;
};

export type PlannerIncomeRow = {
  id: string;
  project_id: string;
  date: string;
  amount: string | number;
  category: string;
  description: string;
  status: string;
};

export type PlannerWorkRow = {
  id: string;
  project_id: string;
  name: string;
  planned_start: string;
  planned_end: string;
  progress_pct?: string | number | null;
  weight?: string | number | null;
  status?: string | null;
};

/** Row from planner_payables linked via creditor_project_id. */
export type PlannerPayableRow = {
  id: string;
  creditor_name: string;
  amount: string | number;
  paid_amount?: string | number | null;
  due_date?: string | null;
  status?: string | null;
};

/** Row from planner_receivables linked via debtor_project_id. */
export type PlannerReceivableRow = {
  id: string;
  debtor_name: string;
  amount: string | number;
  paid_amount?: string | number | null;
  due_date?: string | null;
  status?: string | null;
};

type RapActualAgg = { qty: number; amount: number };

function num(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function dateOnly(value: string): string {
  return value.slice(0, 10);
}

function daysBetween(start: string, end: string): number {
  const ms = new Date(end).getTime() - new Date(start).getTime();
  return Math.max(1, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}

function mapProjectStatus(
  status: string | null | undefined,
  spent: number,
  budget: number,
): MappedProjectView['status'] {
  if (status === 'paused' || status === 'cancelled') return 'danger';
  if (budget > 0 && spent / budget > 0.85) return 'warning';
  return 'ok';
}

function mapWorkStatus(status: string | null | undefined, progress: number): string {
  if (status === 'completed' || progress >= 100) return 'done';
  if (status === 'in_progress' || progress > 0) return 'active';
  return 'pending';
}

function rapStatus(qtyPlan: number, qtyActual: number, total: number, rapTotal: number): string {
  if (total <= 0 && qtyActual <= 0) return 'pending';
  if (total > rapTotal || qtyActual > qtyPlan) return 'over';
  return 'ok';
}

const LABOR_DESC_RE = /\b(upah|tukang|gaji|mandor|pekerja|borongan|jasa|lembur|kuli)\b/i;

function buildActualByRapId(
  costs: PlannerCostRow[],
  rapItems: PlannerRapRow[],
): {
  byRapId: Map<string, RapActualAgg>;
  unlinkedMaterialActual: number;
  unlinkedLaborActual: number;
} {
  const byRapId = new Map<string, RapActualAgg>();
  const rapIds = new Set(rapItems.map(r => r.id));
  let unlinkedMaterialActual = 0;
  let unlinkedLaborActual = 0;

  for (const cost of costs) {
    const amount = num(cost.total_amount);
    let targetRapId = cost.rap_item_id && rapIds.has(cost.rap_item_id) ? cost.rap_item_id : null;

    if (!targetRapId && cost.description && rapItems.length > 0) {
      const cleanDesc = cost.description
        .replace(/^(realisasi|import|biaya)\s*:\s*/i, '')
        .trim()
        .toLowerCase();
      if (cleanDesc) {
        const matched =
          rapItems.find(r => r.name.trim().toLowerCase() === cleanDesc) ||
          rapItems.find(
            r =>
              cleanDesc.includes(r.name.trim().toLowerCase()) ||
              r.name.trim().toLowerCase().includes(cleanDesc),
          );
        if (matched) targetRapId = matched.id;
      }
    }

    if (targetRapId) {
      const agg = byRapId.get(targetRapId) || { qty: 0, amount: 0 };
      let qty = num(cost.quantity);
      if (qty <= 0 && amount > 0) {
        const unitPrice = num(cost.unit_price);
        qty = unitPrice > 0 ? amount / unitPrice : 1;
      }
      agg.qty += qty;
      agg.amount += amount;
      byRapId.set(targetRapId, agg);
    } else if (amount > 0) {
      if (LABOR_DESC_RE.test(cost.description || '')) {
        unlinkedLaborActual += amount;
      } else {
        unlinkedMaterialActual += amount;
      }
    }
  }
  return { byRapId, unlinkedMaterialActual, unlinkedLaborActual };
}

function mapRapItem(row: PlannerRapRow, idx: number, actualByRapId: Map<string, RapActualAgg>): MappedRapItem {
  const qtyPlan = num(row.quantity);
  const unitPrice = num(row.unit_price);
  const rapTotal = qtyPlan * unitPrice;
  const agg = actualByRapId.get(row.id);
  const qtyActual = agg?.qty ?? 0;
  const total = agg?.amount ?? 0;
  return {
    id: idx + 1,
    plannerId: row.id,
    name: row.name,
    unit: row.unit,
    unitPrice,
    qtyPlan,
    qtyActual,
    total,
    rapTotal,
    status: rapStatus(qtyPlan, qtyActual, total, rapTotal),
    checked: qtyActual > 0,
    vendor: row.supplier || '',
  };
}

export function mapPlannerProject(input: {
  project: PlannerProjectRow;
  rapItems: PlannerRapRow[];
  costs: PlannerCostRow[];
  incomes: PlannerIncomeRow[];
  workItems: PlannerWorkRow[];
  /** When set (even empty), hutang comes from planner_payables instead of kas deficit. */
  payables?: PlannerPayableRow[];
  /** When set (even empty), piutang comes from planner_receivables instead of sisa kontrak. */
  receivables?: PlannerReceivableRow[];
}): MappedProjectView {
  const p = input.project;
  const settings = (p.settings || {}) as Record<string, string | number>;
  const contractValue = num(settings.contract_value) || num(p.total_budget);
  const budget = num(p.total_budget);
  const spent = num(p.total_spent);
  const received = num(p.total_received);
  const progress = num(p.progress_pct);
  const { byRapId: actualByRapId, unlinkedMaterialActual, unlinkedLaborActual } = buildActualByRapId(
    input.costs,
    input.rapItems,
  );

  const materials = input.rapItems
    .filter(r => r.type === 'material' || r.type === 'equipment')
    .map((r, idx) => mapRapItem(r, idx, actualByRapId));
  const workers = input.rapItems
    .filter(r => r.type !== 'material' && r.type !== 'equipment')
    .map((r, idx) => mapRapItem(r, idx, actualByRapId));

  const totalRap = [...materials, ...workers].reduce((s, item) => s + item.rapTotal, 0);
  const bahanPlan = materials.reduce((s, item) => s + item.rapTotal, 0);
  const tukangPlan = workers.reduce((s, item) => s + item.rapTotal, 0);
  const bahanActual = materials.reduce((s, item) => s + item.total, 0) + unlinkedMaterialActual;
  const tukangActual = workers.reduce((s, item) => s + item.total, 0) + unlinkedLaborActual;

  const payments = input.incomes
    .filter(i => i.status === 'received')
    .map((inc, idx) => ({
      id: idx + 1,
      type: 'in' as const,
      name: inc.description || `Pembayaran ${inc.category}`,
      amount: num(inc.amount),
      date: dateOnly(inc.date),
      time: '00:00',
      icon: 'arrow-down-circle',
    }));

  const expenses = input.costs.map((cost, idx) => ({
    id: idx + 1,
    type: 'out' as const,
    category: 'Biaya',
    name: cost.description,
    amount: num(cost.total_amount),
    date: dateOnly(cost.date),
    time: '00:00',
    icon: 'arrow-up-circle',
  }));

  const timeline = input.workItems.map((w, idx) => {
    const prog = num(w.progress_pct);
    const wiStart = dateOnly(w.planned_start);
    const wiEnd = dateOnly(w.planned_end);
    return {
      id: idx + 1,
      name: w.name,
      weight: num(w.weight, 10),
      progress: prog,
      planProgress: schedulePlanProgress(wiStart, wiEnd),
      status: mapWorkStatus(w.status, prog),
      start: wiStart,
      end: wiEnd,
    };
  });

  const start = dateOnly(p.planned_start);
  const end = dateOnly(p.planned_end);
  const planProgress = schedulePlanProgress(start, end);
  const actualProgress = input.workItems.length
    ? weightedActualProgress(input.workItems)
    : progress;
  const progressDeviation = actualProgress - planProgress;
  const effectiveProjectedCost =
    totalRap > 0 && totalRap < contractValue ? Math.max(totalRap, spent) : spent;
  const estLaba = Math.max(0, contractValue - effectiveProjectedCost);
  const useLedgerHutang = Array.isArray(input.payables);
  const useLedgerPiutang = Array.isArray(input.receivables);
  const piutang = useLedgerPiutang
    ? sumOutstanding(input.receivables)
    : Math.max(0, contractValue - received);
  const hutang = useLedgerHutang
    ? sumOutstanding(input.payables)
    : Math.max(0, spent - received);
  const extraPiutang = extraPiutangBeyondContract(piutang, contractValue, received);
  const saldo = received - spent - extraPiutang;

  const derivedList = (!useLedgerHutang || !useLedgerPiutang)
    ? buildHutangPiutangList({
        costs: input.costs,
        hutang: useLedgerHutang ? 0 : hutang,
        spent,
        piutang: useLedgerPiutang ? 0 : piutang,
        clientName: p.client_name || 'Klien',
        end,
      })
    : [];

  const hutangPiutang: MappedProjectView['hutangPiutang'] = [
    ...(useLedgerHutang
      ? mapLedgerPayables(input.payables || [], end)
      : derivedList.filter(h => h.type === 'hutang')),
    ...(useLedgerPiutang
      ? mapLedgerReceivables(input.receivables || [], end)
      : derivedList.filter(h => h.type === 'piutang')),
  ].map((item, idx) => ({ ...item, id: idx + 1 }));

  return {
    id: p.id,
    name: p.name,
    client: p.client_name || '-',
    type: settings.type || 'Konstruksi',
    startDate: start,
    endDate: end,
    duration: daysBetween(start, end),
    contractValue,
    saldo,
    status: mapProjectStatus(p.status, spent, budget),
    progress: { plan: planProgress, actual: actualProgress, deviation: progressDeviation },
    rap: {
      totalRAP: totalRap,
      realisasi: spent,
      estLaba,
      materials,
      workers,
    },
    budget: {
      bahan: { plan: bahanPlan, actual: bahanActual },
      tukang: { plan: tukangPlan, actual: tukangActual },
      piutang,
      hutang,
    },
    payments,
    expenses,
    timeline,
    hutangPiutang,
  };
}

function sumOutstanding(
  rows: Array<{ amount: string | number; paid_amount?: string | number | null }> | undefined,
): number {
  if (!rows?.length) return 0;
  return rows.reduce((s, row) => s + Math.max(0, num(row.amount) - num(row.paid_amount)), 0);
}

function ledgerStatus(status: string | null | undefined): string {
  if (status === 'overdue') return 'overdue';
  if (status === 'paid') return 'paid';
  if (status === 'partial') return 'partial';
  return 'upcoming';
}

function mapLedgerPayables(
  rows: PlannerPayableRow[],
  fallbackDue: string,
): MappedProjectView['hutangPiutang'] {
  return rows
    .map((row, idx) => {
      const amount = Math.max(0, num(row.amount) - num(row.paid_amount));
      return {
        id: idx + 1,
        type: 'hutang' as const,
        name: `Hutang ke ${row.creditor_name}`,
        partyName: row.creditor_name,
        amount,
        due: row.due_date ? dateOnly(row.due_date) : fallbackDue,
        status: ledgerStatus(row.status),
      };
    })
    .filter(item => item.amount > 0);
}

function mapLedgerReceivables(
  rows: PlannerReceivableRow[],
  fallbackDue: string,
): MappedProjectView['hutangPiutang'] {
  return rows
    .map((row, idx) => {
      const amount = Math.max(0, num(row.amount) - num(row.paid_amount));
      return {
        id: idx + 1,
        type: 'piutang' as const,
        name: `Piutang dari ${row.debtor_name}`,
        partyName: row.debtor_name,
        amount,
        due: row.due_date ? dateOnly(row.due_date) : fallbackDue,
        status: ledgerStatus(row.status),
      };
    })
    .filter(item => item.amount > 0);
}

const GENERIC_VENDOR = /^(import|vendor|realisasi|biaya|umum)$/i;

function isRealVendorName(supplier: string, description: string): boolean {
  const s = supplier.trim();
  if (!s || GENERIC_VENDOR.test(s)) return false;
  const d = description.trim();
  if (d && s.toLowerCase() === d.toLowerCase()) return false;
  if (d && d.toLowerCase().startsWith('realisasi') && !s.includes(' ')) return false;
  return true;
}

/**
 * Build hutang/piutang list with clear counterparty names (bukan deskripsi biaya).
 */
function buildHutangPiutangList(input: {
  costs: PlannerCostRow[];
  hutang: number;
  spent: number;
  piutang: number;
  clientName: string;
  end: string;
}): MappedProjectView['hutangPiutang'] {
  const items: MappedProjectView['hutangPiutang'] = [];
  let id = 1;

  if (input.hutang > 0) {
    const vendorTotals = new Map<string, number>();
    for (const cost of input.costs) {
      const supplier = cost.supplier?.trim() || '';
      if (!isRealVendorName(supplier, cost.description || '')) continue;
      vendorTotals.set(supplier, (vendorTotals.get(supplier) || 0) + num(cost.total_amount));
    }

    if (vendorTotals.size > 0 && input.spent > 0) {
      for (const [vendor, vendorSpent] of vendorTotals) {
        const share = Math.round(input.hutang * (vendorSpent / input.spent));
        if (share <= 0) continue;
        items.push({
          id: id++,
          type: 'hutang',
          name: `Hutang ke ${vendor}`,
          partyName: vendor,
          amount: share,
          due: input.end,
          status: 'upcoming',
        });
      }
    }

    const listed = items.reduce((s, h) => s + h.amount, 0);
    const remainder = input.hutang - listed;
    if (remainder > 0 || items.length === 0) {
      items.push({
        id: id++,
        type: 'hutang',
        name: 'Hutang Operasional',
        partyName: 'Vendor / Pinjaman',
        amount: remainder > 0 ? remainder : input.hutang,
        due: input.end,
        status: 'upcoming',
      });
    }
  }

  if (input.piutang > 0) {
    items.push({
      id: id++,
      type: 'piutang',
      name: `Piutang dari ${input.clientName}`,
      partyName: input.clientName,
      amount: input.piutang,
      due: input.end,
      status: 'upcoming',
    });
  }

  return items;
}
