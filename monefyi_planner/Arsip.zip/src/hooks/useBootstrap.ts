import { useEffect } from 'react';
import type { Session } from '@supabase/supabase-js';
import { buildUser, setActiveOrgTimeZone } from '../lib/adapters';
import { config } from '../lib/config';
import { onAuthStateChange } from '../services/authService';
import { loadOrg } from '../services/orgService';
import { loadProfile } from '../services/profileService';
import { loadProjects } from '../services/projectService';
import {
  updateLastActive,
  tryDomainJoin,
  createOwnerOrg,
  completeOwnerOnboarding,
} from '../services/onboardingService';
import { supabase } from '../lib/supabase';
import {
  getSignupIntent,
  isOwnerSignupIntent,
  parseOwnerOrgParamsFromMetadata,
} from '../lib/ownerSignup';
import {
  loadNotifications,
  subscribeNotifications,
  subscribeProjects,
} from '../services/notificationService';
import { isPlatformAdmin } from '../services/adminService';
import { logSessionExpired } from '../services/runtimeTracer';
import { initAnalytics, resetAnalytics } from '../lib/analytics/client';
import { useAppStore } from '../store/appStore';
import { bootstrapCustomDomainContext } from '../services/customDomainService';
import { userHasProduct, PRODUCT_NOT_REGISTERED } from '../services/productEntitlements';
import { signOutGlobal } from '../services/authService';

function resolvePlatformRole(profile: { role?: string }): 'user' | 'admin' {
  if (String(profile?.role || '').toLowerCase() === 'admin') return 'admin';
  return 'user';
}

let bootstrapPromise: Promise<void> | null = null;
/** Survives StrictMode remount — jangan ulang spinner jika auth sudah selesai. */
let globalAuthInitDone = false;

async function applyOrgContext(
  authUser: Session['user'],
  profile: { name?: string | null },
  orgCtx: NonNullable<Awaited<ReturnType<typeof loadOrg>>>,
) {
  const store = useAppStore.getState();
  const user = buildUser(authUser, String(profile.name || 'User'), orgCtx.org.id, orgCtx.role);
  store.setUser(user);
  store.setTenant(orgCtx.org);
  setActiveOrgTimeZone(orgCtx.org.timezone);
  store.setAuthenticated(true);
  store.setHasMembership(true);
  store.setSignupIntent(null);
  store.setOnboardingCompleted(!!orgCtx.onboardingCompleted);

  const projects = await loadProjects(orgCtx.org.id, orgCtx.org.currency);
  store.setProjects(projects);

  const notifications = await loadNotifications(authUser.id);
  store.setNotifications(notifications);

  updateLastActive(authUser.id, orgCtx.org.id).catch(console.error);
  store.setLastSynced(new Date());
  store.setSyncStatus('synced');

  initAnalytics(authUser.id, orgCtx.org.id, {
    org_plan: orgCtx.org.plan,
    role: orgCtx.role,
  });
}

async function bootstrapSession(session: Session) {
  const store = useAppStore.getState();
  const authUser = session.user;
  const metadata = authUser.user_metadata as Record<string, unknown>;
  const signupIntent = getSignupIntent(metadata) || null;

  store.setSyncStatus('syncing');
  store.setSignupIntent(signupIntent);
  try {
    const profile = await loadProfile(
      authUser.id,
      authUser.email,
      metadata,
    );
    const platformRole = resolvePlatformRole(profile);
    store.setPlatformRole(platformRole);
    store.setEmailVerified(
      !!authUser.email_confirmed_at ||
        config.skipEmailVerify ||
        platformRole === 'admin',
    );

    let orgCtx = await loadOrg(authUser.id);

    if (!orgCtx) {
      await tryDomainJoin().catch(() => {});
      orgCtx = await loadOrg(authUser.id);
    }

    if (!orgCtx) {
      const ownerParams = parseOwnerOrgParamsFromMetadata(metadata);
      if (ownerParams) {
        try {
          await createOwnerOrg(ownerParams);
          orgCtx = await loadOrg(authUser.id);
        } catch (e) {
          console.error('Auto create owner org:', e);
        }
      }
    }

    const platformAdmin = resolvePlatformRole(profile, authUser.email) === 'admin';
    if (!orgCtx && platformAdmin) {
      const orgName =
        String(metadata.org_name || profile.name || 'Platform Admin Workspace').trim() ||
        'Platform Admin Workspace';
      try {
        await createOwnerOrg({
          org_name: orgName,
          name: String(profile.name || 'Admin'),
        });
        orgCtx = await loadOrg(authUser.id);
        if (orgCtx) {
          await completeOwnerOnboarding(orgCtx.org.id, {});
          await supabase
            .from('profiles')
            .update({ onboarding_completed: true })
            .eq('id', authUser.id);
        }
      } catch (e) {
        console.error('Auto create platform admin org:', e);
      }
    }

    if (orgCtx) {
      await applyOrgContext(authUser, profile, orgCtx);
      return;
    }

    const hasPlanner = await userHasProduct('planner');

    if (!hasPlanner && !signupIntent && !platformAdmin) {
      await signOutGlobal();
      store.setAuthenticated(false);
      store.setUser(null);
      setActiveOrgTimeZone('Asia/Jakarta');
      store.setTenant(null);
      store.setHasMembership(false);
      store.setAuthError(PRODUCT_NOT_REGISTERED);
      throw new Error(PRODUCT_NOT_REGISTERED);
    }

    store.setHasMembership(false);
    store.setUser({
      id: authUser.id,
      name: String(profile.name || 'User'),
      email: authUser.email || '',
      role: isOwnerSignupIntent(metadata) ? 'owner' : 'worker',
      tenant_id: '',
    });
    setActiveOrgTimeZone('Asia/Jakarta');
    store.setTenant(null);
    store.setAuthenticated(true);
    store.setOnboardingCompleted(false);
    store.setProjects([]);
    store.setNotifications([]);
    store.setSyncStatus('synced');
  } catch (e) {
    console.error('Bootstrap error:', e);
    store.setSyncStatus('error');
    store.setAuthError(e instanceof Error ? e.message : 'Gagal memuat data');
    throw e;
  }
}

export function useBootstrap() {
  const {
    setAuthenticated,
    setUser,
    setTenant,
    setProjects,
    setNotifications,
    setAuthInitializing,
    user,
    tenant,
    refreshData,
  } = useAppStore();

  useEffect(() => {
    if (!globalAuthInitDone) {
      setAuthInitializing(true);
    }

    bootstrapCustomDomainContext()
      .then(ctx => useAppStore.getState().setCustomDomainContext(ctx))
      .catch(() => {});

    let initSettled = globalAuthInitDone;
    const settleInit = (reason: string) => {
      if (initSettled) return;
      initSettled = true;
      globalAuthInitDone = true;
      setAuthInitializing(false);
    };

    if (globalAuthInitDone) {
      setAuthInitializing(false);
    }

    const safetyTimer = globalAuthInitDone
      ? null
      : window.setTimeout(() => settleInit('safety-timeout-12s'), 12_000);

    let getSessionHandled = false;

    const processAuth = (event: string, session: Session | null) => {
      if (useAppStore.getState().isDemoMode) {
        settleInit('demo-mode');
        return;
      }

      if (session?.user) {
        if (
          globalAuthInitDone
          && useAppStore.getState().isAuthenticated
          && (event === 'TOKEN_REFRESHED' || event === 'SIGNED_IN' || event === 'INITIAL_SESSION')
        ) {
          return;
        }
        void runBootstrap(session)
          .catch((e) => console.error('Bootstrap error:', e))
          .finally(() => settleInit(`bootstrap-done:${event}`));
        return;
      }

      if (event === 'SIGNED_OUT' || !session) {
        if (useAppStore.getState().user?.id) {
          let wasManual = false;
          try {
            wasManual = sessionStorage.getItem('monefyi_manual_logout') === '1';
            sessionStorage.removeItem('monefyi_manual_logout');
          } catch { /* ignore */ }
          logSessionExpired(wasManual);
        }
        setActiveOrgTimeZone('Asia/Jakarta');
        setUser(null);
        setTenant(null);
        resetAnalytics();
        setAuthenticated(false);
        setProjects([]);
        setNotifications([]);
      }
      settleInit(`no-user:${event}`);
    };

    void supabase.auth.getSession().then(({ data: { session } }) => {
      getSessionHandled = true;
      processAuth('GET_SESSION', session);
    }).catch(() => settleInit('getSession-error'));

    const subscription = onAuthStateChange((event, session) => {
      if (event === 'INITIAL_SESSION' && getSessionHandled) return;
      processAuth(event, session);
    });

    return () => {
      if (safetyTimer != null) window.clearTimeout(safetyTimer);
      subscription.unsubscribe();
    };
  }, [
    setAuthenticated,
    setUser,
    setTenant,
    setProjects,
    setNotifications,
    setAuthInitializing,
  ]);

  useEffect(() => {
    if (!user?.id || !tenant?.id || useAppStore.getState().isDemoMode) return;

    let projectsRefreshTimer: ReturnType<typeof setTimeout> | null = null;
    const scheduleProjectsRefresh = () => {
      if (projectsRefreshTimer) clearTimeout(projectsRefreshTimer);
      projectsRefreshTimer = setTimeout(() => { void refreshData(); }, 500);
    };

    const unsubs: Array<() => void> = [];
    unsubs.push(subscribeNotifications(user.id, () => { void refreshData(); }));
    unsubs.push(subscribeProjects(tenant.id, scheduleProjectsRefresh));

    return () => {
      if (projectsRefreshTimer) clearTimeout(projectsRefreshTimer);
      unsubs.forEach(u => u());
    };
  }, [user?.id, tenant?.id, refreshData]);
}

export async function runBootstrap(session: Session) {
  if (!bootstrapPromise) {
    bootstrapPromise = bootstrapSession(session).finally(() => {
      bootstrapPromise = null;
    });
  }
  return bootstrapPromise;
}
