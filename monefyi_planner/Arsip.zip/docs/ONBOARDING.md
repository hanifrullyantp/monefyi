# Multi-Role Onboarding — Monefyi Planner

## Overview

Production onboarding with secure role assignment:

- **Owner**: registers and creates organization via edge function (no self-assigned roles)
- **Manager/Worker**: join via invitation link, code, email invite, domain auto-join, or join request

## Flows

### Owner
1. `/signup` → **Buat Perusahaan** → `/signup/owner`
2. Email verification (Supabase)
3. Edge function `planner-create-owner-org`
4. `/onboarding/owner` wizard
5. `/app`

### Member (invite link)
1. `/join?token=...`
2. Register or login
3. Edge function `planner-accept-invitation`
4. `/onboarding/member`

### Member (code)
1. `/join-by-code` → enter `XXX-NNN`
2. Same as link flow

### Member (request join)
1. `/find-company` → search public orgs
2. Submit request → owner approves in **Tim → Join Requests**

## Team management

Owners/Managers: **Tim** tab in app sidebar

- Invite modal: link (QR + WA share), email (bulk CSV), join code
- Role changes (owner only)
- Remove members (owner; manager can remove workers)
- Transfer ownership (owner → manager)
- Audit log (owner)
- Access settings: join request, public directory, email domain auto-join

## Database

Apply migrations in order:

```
my-supabase-project/supabase/migrations/20260531120000_planner_onboarding.sql
my-supabase-project/supabase/migrations/20260531120100_planner_onboarding_seed.sql
```

## Edge functions

Deploy from `my-supabase-project/supabase/functions/`:

| Function | Auth | Purpose |
|----------|------|---------|
| planner-create-owner-org | JWT | Create org + owner membership |
| planner-validate-invitation | Public | Preview invite |
| planner-create-invitation | JWT | Generate link/code |
| planner-accept-invitation | JWT | Join org |
| planner-send-invitation-email | JWT | Resend emails |
| planner-revoke-invitation | JWT | Revoke invite |
| planner-submit-join-request | JWT | Submit join request + email admins (Resend) |
| planner-approve-join-request | JWT | Approve request |
| planner-reject-join-request | JWT | Reject request |
| planner-change-member-role | JWT | Role change |
| planner-remove-member | JWT | Soft remove |
| planner-transfer-ownership | JWT | Transfer owner |
| planner-search-companies | Public | Find company |
| planner-try-domain-join | JWT | Domain auto-join |
| planner-analyze | JWT | AI analysis |
| planner-parse-command | JWT | AI command parser |
| auth-send-email | Hook | Signup / verify / reset email (Resend) |
| monefyi-landing-config | GET public, POST admin | Landing page CMS (`slug=planner`) |
| monefyi-admin-users | JWT admin | User list |
| monefyi-admin-update-user | JWT admin | Update user plan / role |
| monefyi-admin-app-config | JWT admin | Global app config |
| monefyi-admin-platform-stats | JWT admin | Platform statistics |
| monefyi-admin-company-types | JWT admin | Company type CRUD |
| monefyi-user-account | JWT | Account settings |

**Total:** 24 functions — deploy semua via `./scripts/deploy-planner-supabase.sh` (termasuk `monefyi-landing-config` dengan `--no-verify-jwt`).

### Deploy (CLI)

Project ref: **Settings → General → Reference ID** (contoh repo: `zzwqfmdyncxbolestkqp`).

```bash
# 1. Buat token: https://supabase.com/dashboard/account/tokens

# 2. Login (pilih salah satu)
npx supabase@latest login --token "sbp_YOUR_TOKEN"
# atau interaktif (buka browser):
npx supabase@latest login

# 3. Deploy migrasi + semua function Planner
export SUPABASE_ACCESS_TOKEN="sbp_YOUR_TOKEN"
export SUPABASE_PROJECT_REF="your-project-ref"
./scripts/deploy-planner-supabase.sh

# Hanya function (tanpa db push):
SKIP_DB_PUSH=1 ./scripts/deploy-planner-supabase.sh
```

Alternatif: GitHub Actions → **Supabase Planner migrate & deploy** (butuh secrets `SUPABASE_ACCESS_TOKEN` + `SUPABASE_PROJECT_REF`).

### Email (semua via Resend + domain monefyi.com)

| Jenis email | Mekanisme | Pengirim |
|-------------|-----------|----------|
| Daftar, verifikasi, reset password, magic link | **Auth Send Email Hook** → `auth-send-email` → Resend API | `Monefyi <noreply@support.monefyi.com>` |
| Undangan tim, welcome, join request, approve/reject, role, remove | Edge Functions → `_shared/email.ts` | `RESEND_FROM_EMAIL` (default `Monefyi <noreply@support.monefyi.com>`) |
| Konfirmasi pembayaran Lynk | `lynk-webhook` → shared Resend | sama |

**Aktifkan hook (sekali, setelah deploy):**

```bash
export SUPABASE_ACCESS_TOKEN="sbp_..."
export SUPABASE_PROJECT_REF="zzwqfmdyncxbolestkqp"
./scripts/enable-auth-email-hook.sh
```

Script ini deploy `auth-send-email`, set `SEND_EMAIL_HOOK_SECRET`, dan enable hook di project Auth config.

**Edge secrets (wajib production):**

```
RESEND_API_KEY
RESEND_FROM_EMAIL=Monefyi <noreply@support.monefyi.com>
SEND_EMAIL_HOOK_SECRET=v1,whsec_...   # dari Auth → Hooks → Send Email
APP_URL=https://planner.monefyi.com
```

User bisa mematikan email transaksional di **Pengaturan → Notifikasi** (`profiles.email_notifications`).

### Edge env vars

```
SUPABASE_URL
SUPABASE_SERVICE_ROLE_KEY
SUPABASE_ANON_KEY
RESEND_API_KEY
RESEND_FROM_EMAIL
APP_URL
APP_CORS_ORIGIN
SKIP_EMAIL_VERIFY=true  # dev only
```

## Frontend env

See `.env.example`. Dev bypass:

```
VITE_SKIP_EMAIL_VERIFY=true
```

## Seed test users

Password: `TestOnboard2026!`

- `owner-onboard@test.monefyi.app` (owner)
- `mgr1-onboard@test.monefyi.app` (manager)
- `worker1-onboard@test.monefyi.app` (worker)
- `hanif.rullyant@gmail.com` (super admin — password dari migrasi `20260531150000_super_admin_hanif.sql`)

## Security

- RLS: no client-side `planner_org_members` INSERT
- Rate limits: 10 invites/day, 5 join requests/day
- Password: min 8, uppercase, digit, symbol
- Email verification required before join (configurable in dev)

## Manual QA checklist

### Onboarding & auth

- [ ] Owner signup → org created → onboarding wizard → masuk `/app`
- [ ] Owner login (setelah verifikasi email) → **tidak** diarahkan ke Cari Perusahaan
- [ ] Owner resume (`/signup/owner?resume=1`) → buat org dari metadata signup
- [ ] Generate invite link → join as worker
- [ ] Email invite (if Resend configured)
- [ ] Join code flow
- [ ] Find company → request → approve
- [ ] Domain auto-join toggle + test
- [ ] Role change / remove / transfer ownership
- [ ] Audit log entries visible

### Per role (login → dashboard)

| Role | Akun seed | Password |
|------|-----------|----------|
| Owner | `owner-onboard@test.monefyi.app` | `TestOnboard2026!` |
| Manager | `mgr1-onboard@test.monefyi.app` | `TestOnboard2026!` |
| Worker | `worker1-onboard@test.monefyi.app` | `TestOnboard2026!` |

- [ ] **Owner:** buat proyek (modal 3 langkah) — tidak error `infinite recursion`
- [ ] **Owner:** detail proyek → tambah RAP / work item / biaya
- [ ] **Owner:** Tim → undang member (generate link)
- [ ] **Owner:** HR & Karyawan → daftar anggota tampil (bukan semua 0 / error 400)
- [ ] **Manager:** buat proyek, lihat semua proyek org
- [ ] **Worker:** hanya lihat proyek yang di-assign (atau pool tanpa assignment)
- [ ] **Super admin:** `hanif.rullyant@gmail.com` → `/admin`, bypass verify email
- [ ] **Super admin:** Landing settings → Save → reload → konten tersimpan

### HR — Absensi & Payroll (database)

Migrasi `20260601150000_planner_attendance_payroll.sql`:

| Tabel | Fungsi |
|-------|--------|
| `planner_attendance_records` | Check-in / check-out per org |
| `planner_member_compensation` | Gaji pokok karyawan |
| `planner_payroll_entries` | Slip gaji bulanan (generate dari absensi) |
| `planner_bon_requests` | Pengajuan bon / pinjaman |

**Alur owner:** HR → Payroll → set gaji pokok → **Generate Payroll Bulan Ini** → Approve → Tandai Lunas.

**Alur worker:** Home → Check In/Out · tab Payroll → lihat slip & ajukan bon.


Setelah `db push`:

```bash
./scripts/rls-smoke-test.sh
```

### Edge functions (otomatis)

Setelah deploy functions:

```bash
export ADMIN_TEST_EMAIL="hanif.rullyant@gmail.com"
export ADMIN_TEST_PASSWORD="..."   # super admin password
./scripts/planner-edge-smoke-test.sh
```

Atau otomatis di akhir `./scripts/deploy-planner-supabase.sh` (set `SKIP_EDGE_SMOKE=1` untuk lewati).

GitHub Actions: tambahkan secret `ADMIN_TEST_PASSWORD` agar admin round-trip test jalan di CI.

Lihat juga [RLS_AUDIT.md](RLS_AUDIT.md) untuk peta policy dan aturan migrasi baru.

**Aturan RLS baru:** jangan subquery silang A→B jika B→A; pakai helper `planner_auth_*()` (lihat migrasi `20260531160200`, `20260601120000`).
